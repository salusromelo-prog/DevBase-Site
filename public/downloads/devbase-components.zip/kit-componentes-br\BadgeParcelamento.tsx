/*
 * BadgeParcelamento — Exibe "em até Nx de R$ XX,XX sem juros"
 *
 * Calcula automaticamente o número máximo de parcelas respeitando o valor
 * mínimo por parcela. Retorna null se o valor for muito baixo.
 *
 * Uso:
 *   // Badge padrão (mínimo R$ 10/parcela)
 *   <BadgeParcelamento totalAmount={299.90} maxInstallments={12} />
 *
 *   // Com mínimo customizado
 *   <BadgeParcelamento totalAmount={49.90} maxInstallments={6} minInstallmentValue={15} />
 *
 *   // Variante compacta (inline)
 *   <BadgeParcelamento totalAmount={299.90} maxInstallments={12} variant="inline" />
 *
 * Dependências: apenas React + Tailwind CSS
 */

import React from 'react'

export interface BadgeParcelamentoProps {
  totalAmount: number
  maxInstallments: number
  minInstallmentValue?: number
  variant?: 'badge' | 'inline' | 'card'
  className?: string
  showTotal?: boolean
}

function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  })
}

function calcBestInstallment(
  total: number,
  maxInstallments: number,
  minInstallmentValue: number,
): number | null {
  if (total <= 0) return null

  // Encontra o máximo de parcelas onde cada parcela ≥ mínimo
  for (let n = maxInstallments; n >= 2; n--) {
    if (total / n >= minInstallmentValue) return n
  }

  // Se nem 2x cabe no mínimo, exibe à vista
  return 1
}

export function BadgeParcelamento({
  totalAmount,
  maxInstallments,
  minInstallmentValue = 10,
  variant = 'badge',
  className = '',
  showTotal = false,
}: BadgeParcelamentoProps) {
  const bestN = calcBestInstallment(totalAmount, maxInstallments, minInstallmentValue)

  if (!bestN) return null

  const installmentValue = totalAmount / bestN
  const isSinglePayment = bestN === 1

  if (variant === 'inline') {
    return (
      <span className={`text-sm text-gray-600 ${className}`}>
        {isSinglePayment ? (
          <>{formatBRL(totalAmount)} à vista</>
        ) : (
          <>
            em até{' '}
            <strong className="text-gray-900">
              {bestN}x de {formatBRL(installmentValue)}
            </strong>{' '}
            sem juros
          </>
        )}
      </span>
    )
  }

  if (variant === 'card') {
    return (
      <div
        className={[
          'rounded-lg border border-green-200 bg-green-50 p-3',
          className,
        ].join(' ')}
      >
        {isSinglePayment ? (
          <p className="text-sm font-semibold text-green-700">
            {formatBRL(totalAmount)}{' '}
            <span className="font-normal text-green-600">à vista</span>
          </p>
        ) : (
          <>
            <p className="text-xs text-green-600">Pagamento parcelado</p>
            <p className="text-lg font-bold text-green-700">
              {bestN}x{' '}
              <span className="text-base">{formatBRL(installmentValue)}</span>
            </p>
            <p className="text-xs text-green-600">sem juros</p>
          </>
        )}
        {showTotal && !isSinglePayment && (
          <p className="mt-1 text-xs text-gray-500">
            Total: {formatBRL(totalAmount)}
          </p>
        )}
      </div>
    )
  }

  // variant === 'badge' (padrão)
  return (
    <span
      className={[
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
        isSinglePayment
          ? 'bg-blue-100 text-blue-800'
          : 'bg-green-100 text-green-800',
        className,
      ].join(' ')}
    >
      {isSinglePayment ? (
        `${formatBRL(totalAmount)} à vista`
      ) : (
        `em até ${bestN}x de ${formatBRL(installmentValue)} sem juros`
      )}
    </span>
  )
}
