/*
 * CPFCNPJInput — Input com máscara automática para CPF e CNPJ
 *
 * Detecta automaticamente CPF (≤11 dígitos) ou CNPJ (>11 dígitos) e aplica
 * a máscara correspondente. Valida os dígitos verificadores ao completar.
 *
 * Uso:
 *   <CPFCNPJInput
 *     value={doc}
 *     onChange={(value, isValid, type) => {
 *       setDoc(value)
 *       console.log(type) // 'cpf' | 'cnpj' | null
 *     }}
 *   />
 *
 * Dependências: apenas React + Tailwind CSS
 */

'use client'

import React, { useState } from 'react'

export interface CPFCNPJInputProps {
  value: string
  onChange: (value: string, isValid: boolean, type: 'cpf' | 'cnpj' | null) => void
  label?: string
  placeholder?: string
  className?: string
  inputClassName?: string
  disabled?: boolean
  required?: boolean
  name?: string
  id?: string
}

function applyMaskCPF(digits: string): string {
  return digits
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
}

function applyMaskCNPJ(digits: string): string {
  return digits
    .replace(/(\d{2})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1/$2')
    .replace(/(\d{4})(\d{1,2})$/, '$1-$2')
}

function validateCPF(digits: string): boolean {
  if (digits.length !== 11 || /^(\d)\1{10}$/.test(digits)) return false

  const calcDigit = (slice: string, factor: number): number => {
    const sum = slice.split('').reduce((acc, d, i) => acc + parseInt(d) * (factor - i), 0)
    const rem = (sum * 10) % 11
    return rem >= 10 ? 0 : rem
  }

  return (
    calcDigit(digits.slice(0, 9), 10) === parseInt(digits[9]) &&
    calcDigit(digits.slice(0, 10), 11) === parseInt(digits[10])
  )
}

function validateCNPJ(digits: string): boolean {
  if (digits.length !== 14 || /^(\d)\1{13}$/.test(digits)) return false

  const calcDigit = (str: string, weights: number[]): number => {
    const sum = str.split('').reduce((acc, d, i) => acc + parseInt(d) * weights[i], 0)
    const rem = sum % 11
    return rem < 2 ? 0 : 11 - rem
  }

  const w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
  const w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]

  return (
    calcDigit(digits.slice(0, 12), w1) === parseInt(digits[12]) &&
    calcDigit(digits.slice(0, 13), w2) === parseInt(digits[13])
  )
}

export function CPFCNPJInput({
  value,
  onChange,
  label = 'CPF / CNPJ',
  placeholder = '000.000.000-00',
  className = '',
  inputClassName = '',
  disabled = false,
  required = false,
  name,
  id,
}: CPFCNPJInputProps) {
  const [error, setError] = useState('')

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = e.target.value.replace(/\D/g, '').slice(0, 14)

    let formatted = digits
    let type: 'cpf' | 'cnpj' | null = null
    let isValid = false

    if (digits.length <= 11) {
      formatted = applyMaskCPF(digits)
      if (digits.length === 11) {
        type = 'cpf'
        isValid = validateCPF(digits)
        setError(isValid ? '' : 'CPF inválido')
      } else {
        setError('')
      }
    } else {
      formatted = applyMaskCNPJ(digits)
      if (digits.length === 14) {
        type = 'cnpj'
        isValid = validateCNPJ(digits)
        setError(isValid ? '' : 'CNPJ inválido')
      } else {
        setError('')
      }
    }

    onChange(formatted, isValid, type)
  }

  const hasError = Boolean(error)

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-gray-700">
          {label}
          {required && <span className="ml-1 text-red-500">*</span>}
        </label>
      )}
      <input
        id={id}
        name={name}
        type="text"
        inputMode="numeric"
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        disabled={disabled}
        required={required}
        aria-invalid={hasError}
        className={[
          'w-full rounded-md border px-3 py-2 text-sm transition-colors',
          'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
          'disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-400',
          hasError ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-white',
          inputClassName,
        ].join(' ')}
      />
      {error && (
        <span className="text-xs text-red-500" role="alert">
          {error}
        </span>
      )}
    </div>
  )
}
