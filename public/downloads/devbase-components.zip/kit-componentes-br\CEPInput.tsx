/*
 * CEPInput — Input de CEP com autocomplete via API ViaCEP
 *
 * Ao digitar os 8 dígitos, busca automaticamente e dispara onAddressFound
 * com os dados de endereço retornados pela ViaCEP (gratuita, sem autenticação).
 *
 * Uso:
 *   <CEPInput
 *     value={cep}
 *     onChange={setCep}
 *     onAddressFound={(addr) => {
 *       setRua(addr.logradouro)
 *       setBairro(addr.bairro)
 *       setCidade(addr.localidade)
 *       setEstado(addr.uf)
 *     }}
 *     onError={(msg) => toast.error(msg)}
 *   />
 *
 * Dependências: apenas React + Tailwind CSS (fetch nativo)
 */

'use client'

import React, { useCallback, useRef } from 'react'

export interface ViaCEPAddress {
  cep: string
  logradouro: string
  complemento: string
  bairro: string
  localidade: string
  uf: string
  ddd: string
  ibge: string
}

export interface CEPInputProps {
  value: string
  onChange: (value: string) => void
  onAddressFound?: (address: ViaCEPAddress) => void
  onError?: (message: string) => void
  label?: string
  placeholder?: string
  className?: string
  inputClassName?: string
  disabled?: boolean
  required?: boolean
  name?: string
  id?: string
}

function applyMaskCEP(digits: string): string {
  return digits.length > 5 ? `${digits.slice(0, 5)}-${digits.slice(5)}` : digits
}

export function CEPInput({
  value,
  onChange,
  onAddressFound,
  onError,
  label = 'CEP',
  placeholder = '00000-000',
  className = '',
  inputClassName = '',
  disabled = false,
  required = false,
  name,
  id,
}: CEPInputProps) {
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState('')
  const abortRef = useRef<AbortController | null>(null)

  const fetchAddress = useCallback(
    async (digits: string) => {
      abortRef.current?.abort()
      abortRef.current = new AbortController()

      setLoading(true)
      setError('')

      try {
        const res = await fetch(`https://viacep.com.br/ws/${digits}/json/`, {
          signal: abortRef.current.signal,
        })

        if (!res.ok) throw new Error('Serviço indisponível')

        const data = await res.json()

        if (data.erro) {
          const msg = 'CEP não encontrado'
          setError(msg)
          onError?.(msg)
          return
        }

        onAddressFound?.(data as ViaCEPAddress)
      } catch (err) {
        if ((err as Error).name === 'AbortError') return
        const msg = 'Erro ao buscar CEP'
        setError(msg)
        onError?.(msg)
      } finally {
        setLoading(false)
      }
    },
    [onAddressFound, onError],
  )

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = e.target.value.replace(/\D/g, '').slice(0, 8)
    const masked = applyMaskCEP(digits)

    setError('')
    onChange(masked)

    if (digits.length === 8) {
      fetchAddress(digits)
    }
  }

  const hasError = Boolean(error)

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-gray-700">
          {label}
          {required && <span className="ml-1 text-red-500">*</span>}
        </label>
      )}
      <div className="relative">
        <input
          id={id}
          name={name}
          type="text"
          inputMode="numeric"
          value={value}
          onChange={handleChange}
          placeholder={placeholder}
          disabled={disabled || loading}
          required={required}
          aria-invalid={hasError}
          className={[
            'w-full rounded-md border px-3 py-2 text-sm transition-colors',
            'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
            'disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-400',
            hasError ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-white',
            loading ? 'pr-9' : '',
            inputClassName,
          ].join(' ')}
        />
        {loading && (
          <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2">
            <svg
              className="h-4 w-4 animate-spin text-blue-500"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
              />
            </svg>
          </div>
        )}
      </div>
      {error && (
        <span className="text-xs text-red-500" role="alert">
          {error}
        </span>
      )}
    </div>
  )
}
