/*
 * SeletorBanco — Select com os 20 principais bancos brasileiros
 *
 * Exibe código ISPB/COMPE + nome do banco. Compatível com formulários
 * controlados. Pode ser usado com react-hook-form via Controller.
 *
 * Uso:
 *   <SeletorBanco
 *     value={banco}
 *     onChange={(banco) => setBanco(banco)}
 *   />
 *
 *   // Com react-hook-form:
 *   <Controller
 *     name="banco"
 *     control={control}
 *     render={({ field }) => <SeletorBanco {...field} />}
 *   />
 *
 * Dependências: apenas React + Tailwind CSS
 */

'use client'

import React from 'react'

export interface Banco {
  codigo: string
  nome: string
  nomeAbreviado: string
}

export const BANCOS_BR: Banco[] = [
  { codigo: '001', nome: 'Banco do Brasil S.A.', nomeAbreviado: 'Banco do Brasil' },
  { codigo: '033', nome: 'Banco Santander (Brasil) S.A.', nomeAbreviado: 'Santander' },
  { codigo: '041', nome: 'Banco do Estado do Rio Grande do Sul S.A.', nomeAbreviado: 'Banrisul' },
  { codigo: '077', nome: 'Banco Inter S.A.', nomeAbreviado: 'Inter' },
  { codigo: '084', nome: 'UniCred Norte do Paraná', nomeAbreviado: 'UniCred' },
  { codigo: '104', nome: 'Caixa Econômica Federal', nomeAbreviado: 'Caixa' },
  { codigo: '208', nome: 'BTG Pactual S.A.', nomeAbreviado: 'BTG Pactual' },
  { codigo: '212', nome: 'Banco Original S.A.', nomeAbreviado: 'Original' },
  { codigo: '237', nome: 'Banco Bradesco S.A.', nomeAbreviado: 'Bradesco' },
  { codigo: '260', nome: 'Nu Pagamentos S.A. (Nubank)', nomeAbreviado: 'Nubank' },
  { codigo: '290', nome: 'PagSeguro Internet S.A. (PagBank)', nomeAbreviado: 'PagBank' },
  { codigo: '323', nome: 'Mercado Pago', nomeAbreviado: 'Mercado Pago' },
  { codigo: '336', nome: 'C6 Bank — Banco C6 S.A.', nomeAbreviado: 'C6 Bank' },
  { codigo: '341', nome: 'Itaú Unibanco S.A.', nomeAbreviado: 'Itaú' },
  { codigo: '380', nome: 'PicPay Serviços S.A.', nomeAbreviado: 'PicPay' },
  { codigo: '422', nome: 'Banco Safra S.A.', nomeAbreviado: 'Safra' },
  { codigo: '633', nome: 'Banco Rendimento S.A.', nomeAbreviado: 'Rendimento' },
  { codigo: '655', nome: 'BV — Banco Votorantim S.A.', nomeAbreviado: 'BV' },
  { codigo: '748', nome: 'Sicredi — Bancoob', nomeAbreviado: 'Sicredi' },
  { codigo: '756', nome: 'Sicoob — Bancoob', nomeAbreviado: 'Sicoob' },
]

export interface SeletorBancoProps {
  value: string
  onChange: (banco: Banco | null) => void
  label?: string
  placeholder?: string
  className?: string
  selectClassName?: string
  disabled?: boolean
  required?: boolean
  name?: string
  id?: string
  mostrarCodigo?: boolean
}

export function SeletorBanco({
  value,
  onChange,
  label = 'Banco',
  placeholder = 'Selecione o banco',
  className = '',
  selectClassName = '',
  disabled = false,
  required = false,
  name,
  id,
  mostrarCodigo = true,
}: SeletorBancoProps) {
  function handleChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const codigo = e.target.value
    const banco = BANCOS_BR.find((b) => b.codigo === codigo) ?? null
    onChange(banco)
  }

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-gray-700">
          {label}
          {required && <span className="ml-1 text-red-500">*</span>}
        </label>
      )}
      <select
        id={id}
        name={name}
        value={value}
        onChange={handleChange}
        disabled={disabled}
        required={required}
        className={[
          'w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm transition-colors',
          'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
          'disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-400',
          !value ? 'text-gray-400' : 'text-gray-900',
          selectClassName,
        ].join(' ')}
      >
        <option value="" disabled>
          {placeholder}
        </option>
        {BANCOS_BR.map((banco) => (
          <option key={banco.codigo} value={banco.codigo}>
            {mostrarCodigo ? `${banco.codigo} — ` : ''}
            {banco.nomeAbreviado}
          </option>
        ))}
      </select>
    </div>
  )
}
