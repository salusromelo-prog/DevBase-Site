/*
 * TelefoneInput — Input com máscara de telefone brasileiro
 *
 * Detecta automaticamente celular (11 dígitos) e fixo (10 dígitos):
 *   Celular: (11) 99999-9999
 *   Fixo:    (11) 9999-9999
 *
 * Uso:
 *   <TelefoneInput
 *     value={telefone}
 *     onChange={(value, type) => {
 *       setTelefone(value)
 *       console.log(type) // 'celular' | 'fixo' | null
 *     }}
 *   />
 *
 * Dependências: apenas React + Tailwind CSS
 */

'use client'

import React from 'react'

export type TipoTelefone = 'celular' | 'fixo' | null

export interface TelefoneInputProps {
  value: string
  onChange: (value: string, type: TipoTelefone) => void
  label?: string
  placeholder?: string
  className?: string
  inputClassName?: string
  disabled?: boolean
  required?: boolean
  name?: string
  id?: string
  showTypeBadge?: boolean
}

function applyMaskTelefone(digits: string): { masked: string; type: TipoTelefone } {
  if (digits.length === 0) return { masked: '', type: null }

  // (XX) — DDD
  if (digits.length <= 2) {
    return { masked: `(${digits}`, type: null }
  }

  const ddd = digits.slice(0, 2)
  const rest = digits.slice(2)

  // Celular tem 9 dígitos no número (começa com 9)
  if (digits.length <= 10) {
    // ainda indefinido ou fixo
    const part1 = rest.slice(0, 4)
    const part2 = rest.slice(4)
    const masked =
      part2.length > 0
        ? `(${ddd}) ${part1}-${part2}`
        : part1.length > 0
          ? `(${ddd}) ${part1}`
          : `(${ddd}) `
    const type: TipoTelefone = digits.length === 10 ? 'fixo' : null
    return { masked, type }
  }

  // 11 dígitos → celular
  const part1 = rest.slice(0, 5)
  const part2 = rest.slice(5)
  const masked =
    part2.length > 0
      ? `(${ddd}) ${part1}-${part2}`
      : `(${ddd}) ${part1}`
  return { masked, type: 'celular' }
}

const TYPE_LABELS: Record<string, string> = {
  celular: 'Celular',
  fixo: 'Fixo',
}

export function TelefoneInput({
  value,
  onChange,
  label = 'Telefone',
  placeholder = '(11) 99999-9999',
  className = '',
  inputClassName = '',
  disabled = false,
  required = false,
  name,
  id,
  showTypeBadge = true,
}: TelefoneInputProps) {
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = e.target.value.replace(/\D/g, '').slice(0, 11)
    const { masked, type } = applyMaskTelefone(digits)
    onChange(masked, type)
  }

  const digits = value.replace(/\D/g, '')
  const currentType: TipoTelefone =
    digits.length === 11 ? 'celular' : digits.length === 10 ? 'fixo' : null

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <div className="flex items-center gap-2">
          <label htmlFor={id} className="text-sm font-medium text-gray-700">
            {label}
            {required && <span className="ml-1 text-red-500">*</span>}
          </label>
          {showTypeBadge && currentType && (
            <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">
              {TYPE_LABELS[currentType]}
            </span>
          )}
        </div>
      )}
      <input
        id={id}
        name={name}
        type="tel"
        inputMode="numeric"
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        disabled={disabled}
        required={required}
        className={[
          'w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm transition-colors',
          'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
          'disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-400',
          inputClassName,
        ].join(' ')}
      />
    </div>
  )
}
