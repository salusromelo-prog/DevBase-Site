// kit-componentes-br — Barrel export
// Importar individualmente para melhor tree-shaking:
//   import { CPFCNPJInput } from '@/kit-componentes-br'

export { CPFCNPJInput } from './CPFCNPJInput'
export type { CPFCNPJInputProps } from './CPFCNPJInput'

export { CEPInput } from './CEPInput'
export type { CEPInputProps, ViaCEPAddress } from './CEPInput'

export { TelefoneInput } from './TelefoneInput'
export type { TelefoneInputProps, TipoTelefone } from './TelefoneInput'

export { SeletorBanco, BANCOS_BR } from './SeletorBanco'
export type { SeletorBancoProps, Banco } from './SeletorBanco'

export { PixButton } from './PixButton'
export type { PixButtonProps } from './PixButton'

export { BadgeParcelamento } from './BadgeParcelamento'
export type { BadgeParcelamentoProps } from './BadgeParcelamento'

export { ParcelamentoSelect } from './ParcelamentoSelect'
export type { ParcelamentoSelectProps, ParcelamentoOption } from './ParcelamentoSelect'

export {
  CartaoForm,
  CartaoNumeroInput,
  CartaoValidadeInput,
  CartaoCVVInput,
  detectBandeira,
} from './CartaoInput'
export type {
  CartaoData,
  CartaoFormProps,
  CartaoNumeroInputProps,
  CartaoValidadeInputProps,
  CartaoCVVInputProps,
  Bandeira,
} from './CartaoInput'
