/*
 * PixButton — Componente de pagamento PIX com QR Code e copia-e-cola
 *
 * Gera o payload EMV/PIX localmente (sem API externa), exibe QR Code e
 * botão de copiar o código. O QR Code é renderizado via qrcode.react.
 *
 * Uso:
 *   <PixButton
 *     pixKey="11999999999"         // celular, CPF, CNPJ, email ou chave aleatória
 *     amount={149.90}
 *     merchantName="Minha Loja"
 *     merchantCity="São Paulo"
 *     description="Pedido #1234"
 *   />
 *
 * Dependências: qrcode.react  →  npm install qrcode.react
 *   Em Next.js App Router, este componente já tem 'use client'.
 */

'use client'

import React, { useCallback, useMemo, useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'

// ─── PIX EMV payload ─────────────────────────────────────────────────────────

function tlv(tag: string, value: string): string {
  return `${tag}${String(value.length).padStart(2, '0')}${value}`
}

function crc16CCITT(str: string): string {
  let crc = 0xffff
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0')
}

function buildPixPayload(
  pixKey: string,
  amount: number,
  merchantName: string,
  merchantCity: string,
  txid?: string,
): string {
  const name = merchantName.normalize('NFD').replace(/[̀-ͯ]/g, '').slice(0, 25)
  const city = merchantCity.normalize('NFD').replace(/[̀-ͯ]/g, '').slice(0, 15)
  const ref = (txid ?? '***').replace(/[^a-zA-Z0-9]/g, '').slice(0, 25) || '***'

  const merchantInfo = tlv('00', 'BR.GOV.BCB.PIX') + tlv('01', pixKey)
  const additionalData = tlv('05', ref)

  const payloadBase =
    tlv('00', '01') +
    tlv('26', merchantInfo) +
    tlv('52', '0000') +
    tlv('53', '986') +
    (amount > 0 ? tlv('54', amount.toFixed(2)) : '') +
    tlv('58', 'BR') +
    tlv('59', name) +
    tlv('60', city) +
    tlv('62', additionalData) +
    '6304'

  return payloadBase + crc16CCITT(payloadBase)
}

// ─── Formatador de moeda ──────────────────────────────────────────────────────

function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

// ─── Componente ───────────────────────────────────────────────────────────────

export interface PixButtonProps {
  pixKey: string
  amount: number
  merchantName: string
  merchantCity?: string
  description?: string
  txid?: string
  qrSize?: number
  className?: string
  onCopy?: () => void
}

export function PixButton({
  pixKey,
  amount,
  merchantName,
  merchantCity = 'Brasil',
  description,
  txid,
  qrSize = 200,
  className = '',
  onCopy,
}: PixButtonProps) {
  const [copied, setCopied] = useState(false)

  const payload = useMemo(
    () => buildPixPayload(pixKey, amount, merchantName, merchantCity, txid),
    [pixKey, amount, merchantName, merchantCity, txid],
  )

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(payload)
      setCopied(true)
      onCopy?.()
      setTimeout(() => setCopied(false), 2500)
    } catch {
      // fallback para ambientes sem Clipboard API
      const ta = document.createElement('textarea')
      ta.value = payload
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.focus()
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
      setCopied(true)
      setTimeout(() => setCopied(false), 2500)
    }
  }, [payload, onCopy])

  return (
    <div
      className={[
        'flex flex-col items-center gap-4 rounded-xl border border-gray-200 bg-white p-6 shadow-sm',
        className,
      ].join(' ')}
    >
      {/* Logo PIX + valor */}
      <div className="flex flex-col items-center gap-1">
        <div className="flex items-center gap-2">
          <svg viewBox="0 0 512 512" className="h-6 w-6" fill="none">
            <path
              d="M126.5 384.5L254.5 256l-128-128.5L254.5 0 510 255.5 254.5 512 126.5 384.5z"
              fill="#32BCAD"
            />
            <path d="M382.5 128L254.5 256l128 128.5L254.5 512 -1 256.5 254.5 0 382.5 128z" fill="#32BCAD" />
          </svg>
          <span className="text-base font-semibold text-gray-800">Pagar com PIX</span>
        </div>
        <span className="text-2xl font-bold text-green-600">{formatBRL(amount)}</span>
        {description && <span className="text-xs text-gray-500">{description}</span>}
      </div>

      {/* QR Code */}
      <div className="rounded-lg border-2 border-gray-100 p-3">
        <QRCodeSVG
          value={payload}
          size={qrSize}
          level="M"
          includeMargin={false}
        />
      </div>

      {/* Instruções */}
      <p className="max-w-xs text-center text-xs text-gray-500">
        Abra o app do seu banco, acesse <strong>PIX</strong> → <strong>Ler QR Code</strong>
      </p>

      {/* Botão copiar */}
      <button
        type="button"
        onClick={handleCopy}
        className={[
          'flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all',
          copied
            ? 'bg-green-500 text-white'
            : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 active:bg-gray-100',
        ].join(' ')}
      >
        {copied ? (
          <>
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            Código copiado!
          </>
        ) : (
          <>
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
              />
            </svg>
            Copiar código PIX
          </>
        )}
      </button>

      <p className="text-center text-[10px] text-gray-400">
        Chave PIX: <span className="font-mono">{pixKey}</span>
      </p>
    </div>
  )
}
