/*
 * ParcelamentoSelect — Select de parcelamento para checkout
 *
 * Gera automaticamente as opções de 1x até maxParcelas.
 * Com jurosMensais = 0, exibe "(sem juros)". Com juros, usa a fórmula
 * Price (SAC) e exibe o total final na opção.
 *
 * A opção 1x (à vista) nunca tem juros, independente de jurosMensais.
 *
 * Uso (sem juros):
 *   <ParcelamentoSelect
 *     valorTotal={299.90}
 *     maxParcelas={12}
 *     value={parcelas}
 *     onChange={(n, opcao) => setParcelas(n)}
 *   />
 *
 * Uso (com juros a partir da 2ª parcela):
 *   <ParcelamentoSelect
 *     valorTotal={299.90}
 *     maxParcelas={12}
 *     jurosMensais={1.99}   // 1,99% ao mês
 *     minValorParcela={15}  // oculta parcelas abaixo de R$ 15 (padrão: 5)
 *     value={parcelas}
 *     onChange={(n, opcao) => {
 *       setParcelas(n)
 *       setTotalFinal(opcao.valorTotalComJuros)
 *     }}
 *   />
 *
 * Dependências: shadcn/ui (Select) + Tailwind CSS
 *   npx shadcn@latest add select
 */

'use client'

import React, { useMemo } from 'react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface ParcelamentoOption {
  parcelas: number
  valorParcela: number
  valorTotalComJuros: number
  temJuros: boolean
}

export interface ParcelamentoSelectProps {
  valorTotal: number
  maxParcelas?: number
  jurosMensais?: number
  minValorParcela?: number
  value?: string
  onChange?: (parcelas: number, opcao: ParcelamentoOption) => void
  label?: string
  placeholder?: string
  disabled?: boolean
  required?: boolean
  className?: string
  name?: string
  id?: string
}

// ─── Cálculo (fórmula Price) ──────────────────────────────────────────────────

function calcParcela(
  valorTotal: number,
  n: number,
  jurosMensais: number,
): ParcelamentoOption {
  // 1x à vista: nunca tem juros
  if (n === 1 || jurosMensais === 0) {
    const valorParcela = valorTotal / n
    return {
      parcelas: n,
      valorParcela,
      valorTotalComJuros: valorTotal,
      temJuros: false,
    }
  }

  // n > 1 com juros: fórmula Price
  const i = jurosMensais / 100
  const fator = Math.pow(1 + i, n)
  const pmt = valorTotal * (i * fator) / (fator - 1)
  const totalComJuros = pmt * n

  return {
    parcelas: n,
    valorParcela: pmt,
    valorTotalComJuros: totalComJuros,
    temJuros: true,
  }
}

// ─── Formatador ───────────────────────────────────────────────────────────────

function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  })
}

function formatLabel(opcao: ParcelamentoOption): string {
  const parcela = formatBRL(opcao.valorParcela)

  if (opcao.parcelas === 1) {
    return `1x de ${parcela} (à vista)`
  }

  if (!opcao.temJuros) {
    return `${opcao.parcelas}x de ${parcela} (sem juros)`
  }

  const total = formatBRL(opcao.valorTotalComJuros)
  return `${opcao.parcelas}x de ${parcela} (total ${total})`
}

// ─── Componente ───────────────────────────────────────────────────────────────

export function ParcelamentoSelect({
  valorTotal,
  maxParcelas = 12,
  jurosMensais = 0,
  minValorParcela = 5,
  value,
  onChange,
  label = 'Parcelas',
  placeholder = 'Selecione o número de parcelas',
  disabled = false,
  required = false,
  className = '',
  name,
  id,
}: ParcelamentoSelectProps) {
  const opcoes = useMemo<ParcelamentoOption[]>(() => {
    const resultado: ParcelamentoOption[] = []

    for (let n = 1; n <= maxParcelas; n++) {
      const opcao = calcParcela(valorTotal, n, jurosMensais)
      if (opcao.valorParcela < minValorParcela && n > 1) break
      resultado.push(opcao)
    }

    return resultado
  }, [valorTotal, maxParcelas, jurosMensais, minValorParcela])

  function handleChange(strValue: string) {
    const n = parseInt(strValue, 10)
    const opcao = opcoes.find((o) => o.parcelas === n)
    if (opcao) onChange?.(n, opcao)
  }

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-gray-700">
          {label}
          {required && <span className="ml-1 text-red-500">*</span>}
        </label>
      )}
      <Select
        value={value}
        onValueChange={handleChange}
        disabled={disabled}
        name={name}
        required={required}
      >
        <SelectTrigger id={id} className="w-full">
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {opcoes.map((opcao) => (
            <SelectItem
              key={opcao.parcelas}
              value={String(opcao.parcelas)}
            >
              <span className="flex items-baseline gap-1.5">
                <span className="font-medium">{formatLabel(opcao)}</span>
                {opcao.temJuros && (
                  <span className="text-xs text-amber-600">
                    +{jurosMensais}% a.m.
                  </span>
                )}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
