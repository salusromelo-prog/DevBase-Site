# Kit Componentes BR

Componentes React/Next.js prontos para o mercado brasileiro. Tailwind CSS + TypeScript. Sem dependências pesadas.

## Instalação

```bash
# Única dependência direta (para o PixButton)
npm install qrcode.react
```

Copie a pasta `kit-componentes-br/` para dentro do seu projeto (ex: `src/components/kit-br/`).

### Requisitos

| Pacote | Versão mínima |
|---|---|
| React | 18+ |
| TypeScript | 5+ |
| Tailwind CSS | 3+ |
| qrcode.react | 3+ (apenas PixButton) |

---

## Dependências externas

A maioria dos componentes não requer instalação adicional. Exceção:

**PixButton** — requer `qrcode.react`:
```bash
npm install qrcode.react
```

---

## Componentes

### CPFCNPJInput

Input com máscara automática que detecta CPF ou CNPJ pelo número de dígitos. Valida os dígitos verificadores ao completar.

```tsx
import { CPFCNPJInput } from '@/components/kit-br'

function Exemplo() {
  const [doc, setDoc] = useState('')

  return (
    <CPFCNPJInput
      value={doc}
      onChange={(value, isValid, type) => {
        setDoc(value)
        // type: 'cpf' | 'cnpj' | null
        // isValid: boolean (true apenas quando completo e válido)
      }}
      label="CPF ou CNPJ"
      required
    />
  )
}
```

**Props:**

| Prop | Tipo | Padrão | Descrição |
|---|---|---|---|
| `value` | `string` | — | Valor controlado |
| `onChange` | `(value, isValid, type) => void` | — | Callback ao mudar |
| `label` | `string` | `'CPF / CNPJ'` | Label do campo |
| `placeholder` | `string` | `'000.000.000-00'` | Placeholder |
| `disabled` | `boolean` | `false` | Desabilita o input |
| `required` | `boolean` | `false` | Marca como obrigatório |

---

### CEPInput

Input de CEP com busca automática na API ViaCEP (gratuita, sem autenticação). Ao digitar 8 dígitos, busca e dispara `onAddressFound`.

```tsx
import { CEPInput } from '@/components/kit-br'

function Exemplo() {
  const [cep, setCep] = useState('')
  const [endereco, setEndereco] = useState({
    rua: '', bairro: '', cidade: '', estado: ''
  })

  return (
    <>
      <CEPInput
        value={cep}
        onChange={setCep}
        onAddressFound={(addr) => {
          setEndereco({
            rua: addr.logradouro,
            bairro: addr.bairro,
            cidade: addr.localidade,
            estado: addr.uf,
          })
        }}
        onError={(msg) => console.error(msg)}
      />

      <input placeholder="Rua" value={endereco.rua} readOnly />
      <input placeholder="Bairro" value={endereco.bairro} readOnly />
      <input placeholder="Cidade" value={endereco.cidade} readOnly />
      <input placeholder="UF" value={endereco.estado} readOnly />
    </>
  )
}
```

**Objeto `ViaCEPAddress`:**

```ts
{
  cep: string          // "01001-000"
  logradouro: string   // "Praça da Sé"
  complemento: string
  bairro: string       // "Sé"
  localidade: string   // "São Paulo"
  uf: string           // "SP"
  ddd: string          // "11"
  ibge: string         // código IBGE
}
```

---

### TelefoneInput

Input com máscara de telefone brasileiro. Detecta automaticamente celular `(11) 99999-9999` e fixo `(11) 9999-9999`.

```tsx
import { TelefoneInput } from '@/components/kit-br'

function Exemplo() {
  const [tel, setTel] = useState('')

  return (
    <TelefoneInput
      value={tel}
      onChange={(value, type) => {
        setTel(value)
        // type: 'celular' | 'fixo' | null
      }}
      label="Telefone / WhatsApp"
      showTypeBadge // exibe badge "Celular" ou "Fixo"
    />
  )
}
```

---

### SeletorBanco

Select com os 20 principais bancos brasileiros (código COMPE + nome). Lista disponível em `BANCOS_BR`.

```tsx
import { SeletorBanco, BANCOS_BR } from '@/components/kit-br'

function Exemplo() {
  const [banco, setBanco] = useState('')

  return (
    <SeletorBanco
      value={banco}
      onChange={(banco) => {
        if (banco) {
          console.log(banco.codigo) // "341"
          console.log(banco.nome)   // "Itaú Unibanco S.A."
          setBanco(banco.codigo)
        }
      }}
      label="Banco"
      mostrarCodigo // exibe "341 — Itaú"
    />
  )
}
```

**Bancos incluídos:** Banco do Brasil, Santander, Banrisul, Inter, UniCred, Caixa, BTG Pactual, Original, Bradesco, Nubank, PagBank, Mercado Pago, C6 Bank, Itaú, PicPay, Safra, Rendimento, BV, Sicredi, Sicoob.

---

### PixButton

Componente de pagamento PIX. Gera o payload EMV localmente (sem API externa), exibe QR Code via `qrcode.react` e botão de copia-e-cola.

```tsx
import { PixButton } from '@/components/kit-br'

function Exemplo() {
  return (
    <PixButton
      pixKey="11999999999"       // celular, CPF, CNPJ, email ou chave aleatória
      amount={149.90}
      merchantName="Minha Loja"
      merchantCity="São Paulo"
      description="Pedido #1234"
      txid="pedido1234"          // referência (opcional, máx 25 chars)
      qrSize={200}
      onCopy={() => toast.success('Código copiado!')}
    />
  )
}
```

> **Requer:** `npm install qrcode.react`
>
> Em Next.js App Router, o componente já declara `'use client'`.

---

### BadgeParcelamento

Badge/texto que exibe as condições de parcelamento. Calcula automaticamente o melhor número de parcelas respeitando o valor mínimo.

```tsx
import { BadgeParcelamento } from '@/components/kit-br'

function Exemplo() {
  return (
    <>
      {/* Badge padrão (verde, inline) */}
      <BadgeParcelamento totalAmount={299.90} maxInstallments={12} />
      {/* → "em até 12x de R$ 24,99 sem juros" */}

      {/* Variante inline (dentro de texto) */}
      <BadgeParcelamento
        totalAmount={299.90}
        maxInstallments={12}
        variant="inline"
      />

      {/* Variante card (bloco verde) */}
      <BadgeParcelamento
        totalAmount={299.90}
        maxInstallments={6}
        minInstallmentValue={30}  // parcela mínima (padrão: R$ 10)
        variant="card"
        showTotal
      />
    </>
  )
}
```

---

### ParcelamentoSelect

Select de parcelas para checkout. Gera automaticamente as opções de 1x até `maxParcelas`. Suporta juros via fórmula Price — a opção **1x à vista** nunca tem juros. Usa o componente `Select` do **shadcn/ui**.

```tsx
import { ParcelamentoSelect } from '@/components/kit-br'
import type { ParcelamentoOption } from '@/components/kit-br'

function Exemplo() {
  const [parcelas, setParcelas] = useState('1')
  const [totalFinal, setTotalFinal] = useState(299.90)

  return (
    <ParcelamentoSelect
      valorTotal={299.90}
      maxParcelas={12}
      value={parcelas}
      onChange={(n, opcao) => {
        setParcelas(String(n))
        setTotalFinal(opcao.valorTotalComJuros)
      }}
    />
  )
}
```

**Com juros a partir da 2ª parcela:**

```tsx
<ParcelamentoSelect
  valorTotal={299.90}
  maxParcelas={12}
  jurosMensais={1.99}    // 1,99% ao mês (fórmula Price)
  minValorParcela={15}   // oculta parcelas < R$ 15 (padrão: R$ 5)
  value={parcelas}
  onChange={(n, opcao) => {
    setParcelas(String(n))
    setTotalFinal(opcao.valorTotalComJuros)
    // opcao.temJuros: boolean
    // opcao.valorParcela: number (valor de cada parcela)
    // opcao.valorTotalComJuros: number (total pago)
  }}
/>
```

**Opções geradas (exemplo `valorTotal=299.90`, `jurosMensais=1.99`):**

| Opção exibida | temJuros |
|---|---|
| `1x de R$ 299,90 (à vista)` | false |
| `2x de R$ 152,87 (total R$ 305,74)` | true |
| `3x de R$ 102,73 (total R$ 308,19)` | true |
| `…` | true |

**Props:**

| Prop | Tipo | Padrão | Descrição |
|---|---|---|---|
| `valorTotal` | `number` | — | Valor base do pedido |
| `maxParcelas` | `number` | `12` | Máximo de parcelas exibidas |
| `jurosMensais` | `number` | `0` | Taxa mensal em % (0 = sem juros) |
| `minValorParcela` | `number` | `5` | Oculta parcelas abaixo deste valor |
| `value` | `string` | — | Valor controlado (ex: `"3"`) |
| `onChange` | `(n, opcao) => void` | — | Callback com nº de parcelas e dados |
| `label` | `string` | `'Parcelas'` | Label do campo |
| `disabled` | `boolean` | `false` | Desabilita o select |

> **Requer shadcn/ui Select:**
> ```bash
> npx shadcn@latest add select
> ```

---

### CartaoInput / CartaoForm

Formulário completo de cartão de crédito. Detecta bandeira (Visa, Mastercard, Elo, Amex, Hipercard), valida número com Luhn, formata validade e CVV.

```tsx
import { CartaoForm } from '@/components/kit-br'
import type { CartaoData } from '@/components/kit-br'

const CARTAO_VAZIO: CartaoData = {
  numero: '',
  nomeTitular: '',
  validade: '',
  cvv: '',
  bandeira: 'desconhecida',
}

function Exemplo() {
  const [cartao, setCartao] = useState<CartaoData>(CARTAO_VAZIO)
  const [valido, setValido] = useState(false)

  return (
    <form onSubmit={...}>
      <CartaoForm
        value={cartao}
        onChange={setCartao}
        onValidChange={setValido}
      />
      <button disabled={!valido}>Pagar</button>
    </form>
  )
}
```

**Uso com inputs individuais:**

```tsx
import { CartaoNumeroInput, CartaoValidadeInput, CartaoCVVInput } from '@/components/kit-br'

// Use separados no seu próprio layout
<CartaoNumeroInput value={numero} onChange={(v, bandeira, isValid) => ...} />
<CartaoValidadeInput value={validade} onChange={(v, isValid) => ...} />
<CartaoCVVInput value={cvv} bandeira={bandeira} onChange={(v, isValid) => ...} />
```

---

## Licença

MIT — livre para uso comercial.
