/*
 * CartaoInput — Formulário completo de cartão de crédito
 *
 * Detecta a bandeira pelo BIN (Visa, Mastercard, Elo, Amex, Hipercard),
 * aplica máscara de número, valida com Luhn, formata validade e CVV.
 * Exporta também os sub-componentes individuais para uso avulso.
 *
 * Uso (formulário completo):
 *   <CartaoForm
 *     value={cartao}
 *     onChange={setCartao}
 *     onValidChange={(isValid) => setCanSubmit(isValid)}
 *   />
 *
 * Uso (inputs individuais):
 *   <CartaoNumeroInput value={numero} onChange={setNumero} />
 *   <CartaoValidadeInput value={validade} onChange={setValidade} />
 *   <CartaoCVVInput value={cvv} onChange={setCvv} bandeira={bandeira} />
 *
 * Dependências: apenas React + Tailwind CSS
 */

'use client'

import React, { useState } from 'react'

// ─── Bandeiras ────────────────────────────────────────────────────────────────

export type Bandeira = 'visa' | 'mastercard' | 'elo' | 'amex' | 'hipercard' | 'desconhecida'

const BANDEIRA_PATTERNS: Array<{ bandeira: Bandeira; regex: RegExp }> = [
  { bandeira: 'amex', regex: /^3[47]/ },
  { bandeira: 'hipercard', regex: /^(606282|637095|637568|637599|637609|637612)/ },
  {
    bandeira: 'elo',
    regex:
      /^(4011|4312|4389|4514|4573|4576|5041|5066|5067|5090|6277|6362|6363|6516|6550|636368|438935|504175|451416|509048|509067|509049|509069|509550|509551|509552|509553|509554|509555)/,
  },
  { bandeira: 'mastercard', regex: /^(5[1-5]|2[2-7])/ },
  { bandeira: 'visa', regex: /^4/ },
]

export function detectBandeira(digits: string): Bandeira {
  for (const { bandeira, regex } of BANDEIRA_PATTERNS) {
    if (regex.test(digits)) return bandeira
  }
  return 'desconhecida'
}

const BANDEIRA_LABELS: Record<Bandeira, string> = {
  visa: 'Visa',
  mastercard: 'Mastercard',
  elo: 'Elo',
  amex: 'American Express',
  hipercard: 'Hipercard',
  desconhecida: '',
}

const BANDEIRA_COLORS: Record<Bandeira, string> = {
  visa: 'bg-blue-100 text-blue-800',
  mastercard: 'bg-red-100 text-red-800',
  elo: 'bg-yellow-100 text-yellow-800',
  amex: 'bg-indigo-100 text-indigo-800',
  hipercard: 'bg-rose-100 text-rose-800',
  desconhecida: 'bg-gray-100 text-gray-600',
}

// ─── Máscara e validação ──────────────────────────────────────────────────────

function applyMaskCartao(digits: string, bandeira: Bandeira): string {
  if (bandeira === 'amex') {
    // 4-6-5
    return digits
      .replace(/(\d{4})(\d{1,6})/, '$1 $2')
      .replace(/(\d{4} \d{6})(\d{1,5})/, '$1 $2')
  }
  // 4-4-4-4
  return digits.replace(/(\d{4})(?=\d)/g, '$1 ').trim()
}

function luhn(digits: string): boolean {
  if (digits.length < 13) return false
  let sum = 0
  let isOdd = false
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = parseInt(digits[i])
    if (isOdd) {
      d *= 2
      if (d > 9) d -= 9
    }
    sum += d
    isOdd = !isOdd
  }
  return sum % 10 === 0
}

function applyMaskValidade(raw: string): string {
  const digits = raw.replace(/\D/g, '').slice(0, 4)
  if (digits.length <= 2) return digits
  return `${digits.slice(0, 2)}/${digits.slice(2)}`
}

function validateValidade(masked: string): boolean {
  const [m, y] = masked.split('/')
  if (!m || !y || y.length < 2) return false
  const month = parseInt(m)
  if (month < 1 || month > 12) return false
  const now = new Date()
  const expYear = 2000 + parseInt(y)
  const expMonth = month
  return expYear > now.getFullYear() || (expYear === now.getFullYear() && expMonth >= now.getMonth() + 1)
}

// ─── Sub-componentes ──────────────────────────────────────────────────────────

export interface CartaoNumeroInputProps {
  value: string
  onChange: (value: string, bandeira: Bandeira, isValid: boolean) => void
  className?: string
  label?: string
  id?: string
  name?: string
}

export function CartaoNumeroInput({
  value,
  onChange,
  className = '',
  label = 'Número do cartão',
  id,
  name,
}: CartaoNumeroInputProps) {
  const digits = value.replace(/\D/g, '')
  const bandeira = detectBandeira(digits)
  const maxLen = bandeira === 'amex' ? 15 : 16

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const d = e.target.value.replace(/\D/g, '').slice(0, maxLen)
    const b = detectBandeira(d)
    const max = b === 'amex' ? 15 : 16
    const masked = applyMaskCartao(d.slice(0, max), b)
    const valid = d.length === max && luhn(d)
    onChange(masked, b, valid)
  }

  const label_bandeira = BANDEIRA_LABELS[bandeira]

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label htmlFor={id} className="text-sm font-medium text-gray-700">
            {label}
          </label>
          {label_bandeira && (
            <span
              className={`rounded-full px-2 py-0.5 text-xs font-semibold ${BANDEIRA_COLORS[bandeira]}`}
            >
              {label_bandeira}
            </span>
          )}
        </div>
      )}
      <input
        id={id}
        name={name}
        type="text"
        inputMode="numeric"
        value={value}
        onChange={handleChange}
        placeholder="0000 0000 0000 0000"
        maxLength={bandeira === 'amex' ? 17 : 19}
        className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 font-mono text-sm tracking-widest focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
    </div>
  )
}

export interface CartaoValidadeInputProps {
  value: string
  onChange: (value: string, isValid: boolean) => void
  className?: string
  label?: string
  id?: string
  name?: string
}

export function CartaoValidadeInput({
  value,
  onChange,
  className = '',
  label = 'Validade',
  id,
  name,
}: CartaoValidadeInputProps) {
  const [error, setError] = useState('')

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const masked = applyMaskValidade(e.target.value)
    const valid = masked.length === 5 && validateValidade(masked)

    if (masked.length === 5) {
      setError(valid ? '' : 'Data inválida ou expirada')
    } else {
      setError('')
    }

    onChange(masked, valid)
  }

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-gray-700">
          {label}
        </label>
      )}
      <input
        id={id}
        name={name}
        type="text"
        inputMode="numeric"
        value={value}
        onChange={handleChange}
        placeholder="MM/AA"
        maxLength={5}
        className={[
          'w-full rounded-md border px-3 py-2 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
          error ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-white',
        ].join(' ')}
      />
      {error && <span className="text-xs text-red-500">{error}</span>}
    </div>
  )
}

export interface CartaoCVVInputProps {
  value: string
  onChange: (value: string, isValid: boolean) => void
  bandeira?: Bandeira
  className?: string
  label?: string
  id?: string
  name?: string
}

export function CartaoCVVInput({
  value,
  onChange,
  bandeira = 'desconhecida',
  className = '',
  label = 'CVV',
  id,
  name,
}: CartaoCVVInputProps) {
  const maxLen = bandeira === 'amex' ? 4 : 3

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = e.target.value.replace(/\D/g, '').slice(0, maxLen)
    onChange(digits, digits.length === maxLen)
  }

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-gray-700">
          {label}
          <span className="ml-1 text-xs font-normal text-gray-400">
            ({maxLen} dígitos)
          </span>
        </label>
      )}
      <input
        id={id}
        name={name}
        type="password"
        inputMode="numeric"
        value={value}
        onChange={handleChange}
        placeholder={'•'.repeat(maxLen)}
        maxLength={maxLen}
        className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
    </div>
  )
}

// ─── Formulário completo ──────────────────────────────────────────────────────

export interface CartaoData {
  numero: string
  nomeTitular: string
  validade: string
  cvv: string
  bandeira: Bandeira
}

export interface CartaoFormProps {
  value: CartaoData
  onChange: (data: CartaoData) => void
  onValidChange?: (isValid: boolean) => void
  className?: string
}

export function CartaoForm({ value, onChange, onValidChange, className = '' }: CartaoFormProps) {
  const [validity, setValidity] = useState({
    numero: false,
    nomeTitular: false,
    validade: false,
    cvv: false,
  })

  function checkValidity(next: typeof validity) {
    const all = Object.values(next).every(Boolean)
    onValidChange?.(all)
  }

  function setField<K extends keyof CartaoData>(key: K, val: CartaoData[K]) {
    onChange({ ...value, [key]: val })
  }

  return (
    <div className={`flex flex-col gap-4 ${className}`}>
      <CartaoNumeroInput
        value={value.numero}
        label="Número do cartão"
        onChange={(numero, bandeira, isValid) => {
          const next = { ...validity, numero: isValid }
          setValidity(next)
          checkValidity(next)
          onChange({ ...value, numero, bandeira })
        }}
      />

      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium text-gray-700">Nome no cartão</label>
        <input
          type="text"
          value={value.nomeTitular}
          onChange={(e) => {
            const nome = e.target.value.toUpperCase()
            const next = { ...validity, nomeTitular: nome.trim().length >= 3 }
            setValidity(next)
            checkValidity(next)
            setField('nomeTitular', nome)
          }}
          placeholder="NOME COMO NO CARTÃO"
          autoComplete="cc-name"
          className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm tracking-wide focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <CartaoValidadeInput
          value={value.validade}
          onChange={(validade, isValid) => {
            const next = { ...validity, validade: isValid }
            setValidity(next)
            checkValidity(next)
            setField('validade', validade)
          }}
        />
        <CartaoCVVInput
          value={value.cvv}
          bandeira={value.bandeira}
          onChange={(cvv, isValid) => {
            const next = { ...validity, cvv: isValid }
            setValidity(next)
            checkValidity(next)
            setField('cvv', cvv)
          }}
        />
      </div>
    </div>
  )
}
