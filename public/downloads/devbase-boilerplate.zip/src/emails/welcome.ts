import { APP_NAME, APP_URL } from "@/lib/resend";

interface WelcomeEmailProps {
  nome: string;
  dashboardUrl?: string;
}

export function emailBoasVindas({ nome, dashboardUrl }: WelcomeEmailProps): string {
  const dashboard = dashboardUrl ?? `${APP_URL}/dashboard`;
  const primeiroNome = nome.split(" ")[0];

  return /* html */ `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Bem-vindo ao ${APP_NAME}</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:ui-monospace,'Fira Code','Cascadia Code',monospace;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 16px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:#0a0a0a;border-radius:12px 12px 0 0;padding:28px 32px;text-align:center;">
              <span style="color:#ffffff;font-size:20px;font-weight:700;letter-spacing:-0.03em;">
                ${APP_NAME}<span style="color:#6366f1;">.</span>
              </span>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="background:#ffffff;padding:40px 32px;">
              <p style="margin:0 0 6px;font-size:11px;color:#6b7280;letter-spacing:0.05em;text-transform:uppercase;">
                // bem-vindo
              </p>
              <h1 style="margin:0 0 24px;font-size:26px;font-weight:700;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.2;">
                olá, <span style="color:#6366f1;">${primeiroNome}</span> 👋
              </h1>

              <p style="margin:0 0 16px;font-size:14px;color:#374151;line-height:1.7;">
                Sua conta no <strong>${APP_NAME}</strong> foi criada com sucesso.
                Você já pode acessar o dashboard e começar a construir seu SaaS.
              </p>

              <p style="margin:0 0 32px;font-size:14px;color:#374151;line-height:1.7;">
                O kit já vem com autenticação, billing, dashboard e muito mais
                — tudo em português, pronto para produção.
              </p>

              <!-- CTA -->
              <table cellpadding="0" cellspacing="0" style="margin:0 0 32px;">
                <tr>
                  <td style="background:#6366f1;border-radius:8px;">
                    <a href="${dashboard}"
                       style="display:inline-block;padding:13px 28px;color:#ffffff;font-size:14px;font-weight:600;text-decoration:none;letter-spacing:-0.01em;">
                      acessar o dashboard →
                    </a>
                  </td>
                </tr>
              </table>

              <!-- Divider -->
              <hr style="border:none;border-top:1px solid #e5e7eb;margin:0 0 24px;" />

              <!-- Quick tips -->
              <p style="margin:0 0 12px;font-size:12px;color:#6b7280;">próximos passos:</p>
              <table cellpadding="0" cellspacing="0" width="100%">
                ${[
                  ["01", "configure suas variáveis de ambiente"],
                  ["02", "conecte o Pagar.me para billing"],
                  ["03", "personalize nome, cores e textos"],
                  ["04", "faça o deploy na Vercel"],
                ].map(([n, t]) => `
                <tr>
                  <td style="padding:6px 0;vertical-align:top;">
                    <span style="display:inline-block;width:24px;height:24px;background:#f4f4f5;border-radius:4px;text-align:center;line-height:24px;font-size:10px;font-weight:700;color:#6366f1;margin-right:10px;">${n}</span>
                    <span style="font-size:13px;color:#374151;">${t}</span>
                  </td>
                </tr>`).join("")}
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f9fafb;border-radius:0 0 12px 12px;padding:20px 32px;border-top:1px solid #e5e7eb;text-align:center;">
              <p style="margin:0 0 4px;font-size:12px;color:#9ca3af;">
                Você está recebendo este email porque criou uma conta no ${APP_NAME}.
              </p>
              <p style="margin:0;font-size:12px;color:#9ca3af;">
                <a href="${APP_URL}" style="color:#6366f1;text-decoration:none;">${APP_URL.replace(/^https?:\/\//, "")}</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}
