import { APP_NAME, APP_URL } from "@/lib/resend";

interface ResetSenhaEmailProps {
  resetUrl: string;
}

export function emailResetSenha({ resetUrl }: ResetSenhaEmailProps): string {
  return /* html */ `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Redefinição de senha — ${APP_NAME}</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:ui-monospace,'Fira Code','Cascadia Code',monospace;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 16px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:#0a0a0a;border-radius:12px 12px 0 0;padding:28px 32px;text-align:center;">
              <span style="color:#ffffff;font-size:20px;font-weight:700;letter-spacing:-0.03em;">
                ${APP_NAME}<span style="color:#6366f1;">.</span>
              </span>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="background:#ffffff;padding:40px 32px;">
              <p style="margin:0 0 6px;font-size:11px;color:#6b7280;letter-spacing:0.05em;text-transform:uppercase;">
                // segurança da conta
              </p>
              <h1 style="margin:0 0 24px;font-size:26px;font-weight:700;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.2;">
                redefinição de senha
              </h1>

              <p style="margin:0 0 16px;font-size:14px;color:#374151;line-height:1.7;">
                Recebemos uma solicitação para redefinir a senha da sua conta no
                <strong>${APP_NAME}</strong>. Clique no botão abaixo para criar
                uma nova senha.
              </p>

              <p style="margin:0 0 32px;font-size:14px;color:#374151;line-height:1.7;">
                O link é válido por <strong>1 hora</strong>. Após esse prazo,
                você precisará solicitar um novo link.
              </p>

              <!-- CTA -->
              <table cellpadding="0" cellspacing="0" style="margin:0 0 32px;">
                <tr>
                  <td style="background:#6366f1;border-radius:8px;">
                    <a href="${resetUrl}"
                       style="display:inline-block;padding:13px 28px;color:#ffffff;font-size:14px;font-weight:600;text-decoration:none;letter-spacing:-0.01em;">
                      redefinir minha senha →
                    </a>
                  </td>
                </tr>
              </table>

              <!-- Fallback URL -->
              <p style="margin:0 0 8px;font-size:12px;color:#6b7280;">
                Se o botão não funcionar, copie e cole o link abaixo no seu navegador:
              </p>
              <p style="margin:0 0 32px;font-size:11px;word-break:break-all;">
                <a href="${resetUrl}" style="color:#6366f1;text-decoration:none;">${resetUrl}</a>
              </p>

              <!-- Divider -->
              <hr style="border:none;border-top:1px solid #e5e7eb;margin:0 0 24px;" />

              <!-- Security note -->
              <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td style="background:#fef9c3;border:1px solid #fde68a;border-radius:8px;padding:14px 16px;">
                    <p style="margin:0;font-size:12px;color:#92400e;line-height:1.6;">
                      <strong>Não solicitou a redefinição?</strong><br />
                      Ignore este email — sua senha não será alterada e sua conta
                      permanece segura. Se isso acontecer com frequência, entre em
                      contato conosco.
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f9fafb;border-radius:0 0 12px 12px;padding:20px 32px;border-top:1px solid #e5e7eb;text-align:center;">
              <p style="margin:0 0 4px;font-size:12px;color:#9ca3af;">
                Por segurança, nunca compartilhe este link com ninguém.
              </p>
              <p style="margin:0;font-size:12px;color:#9ca3af;">
                <a href="${APP_URL}" style="color:#6366f1;text-decoration:none;">${APP_URL.replace(/^https?:\/\//, "")}</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}
