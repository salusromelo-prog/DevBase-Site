"use client";
import { useEffect, useRef, useState } from "react";

const STATS = [
  { value: 2,   label: "de setup", unit: "~", suffix: "h" },
  { value: 8,   label: "integrações",           unit: "",  suffix: "" },
  { value: 100, label: "PT-BR",                 unit: "",  suffix: "%" },
];

function StatItem({ value, label, unit, suffix }: { value: number; label: string; unit: string; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const activated = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !activated.current) {
          activated.current = true;
          if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
            setCount(value);
            observer.disconnect();
            return;
          }
          const duration = 1400;
          const start = performance.now();
          const step = (now: number) => {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.round(eased * value));
            if (progress < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
          observer.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);

  return (
    <div ref={ref} className="text-center px-6 py-2">
      <div className="font-bold mb-0.5" style={{ fontSize: "1.75rem", fontFamily: "monospace", color: "var(--accent-2)", letterSpacing: "-0.04em" }}>
        {unit}{count}{suffix}
      </div>
      <div className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>{label}</div>
    </div>
  );
}

export function StatsCounter() {
  return (
    <div className="flex flex-wrap items-center justify-center gap-2 rounded-xl mb-6"
      style={{ background: "var(--bg-3)", border: "1px solid var(--border)" }}>
      {STATS.map((s, i) => (
        <div key={s.label} className="flex items-center">
          <StatItem {...s} />
          {i < STATS.length - 1 && (
            <div className="h-6 w-px" style={{ background: "var(--border)" }} />
          )}
        </div>
      ))}
    </div>
  );
}
