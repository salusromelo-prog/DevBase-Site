type Variant = 'primary' | 'mono' | 'light' | 'outline';

interface LogoProps {
  size?: number;
  showWordmark?: boolean;
  variant?: Variant;
  className?: string;
}

const CUBE_TOP   = 'M32 12 L50 22 L32 32 L14 22 Z';
const CUBE_LEFT  = 'M14 22 L32 32 L32 50 L14 40 Z';
const CUBE_RIGHT = 'M50 22 L32 32 L32 50 L50 40 Z';

function Icon({ size, variant }: { size: number; variant: Variant }) {
  if (variant === 'mono') {
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden>
        <rect width="64" height="64" rx="12" fill="#0a0a0a" stroke="rgba(255,255,255,0.14)" />
        <path d={CUBE_TOP}   fill="#fff" />
        <path d={CUBE_LEFT}  fill="#fff" opacity="0.7" />
        <path d={CUBE_RIGHT} fill="#fff" opacity="0.4" />
        <line x1="12" y1="55" x2="52" y2="55" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
      </svg>
    );
  }
  if (variant === 'light') {
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden>
        <rect width="64" height="64" rx="12" fill="#0a0a0a" />
        <path d={CUBE_TOP}   fill="#818cf8" />
        <path d={CUBE_LEFT}  fill="#6366f1" />
        <path d={CUBE_RIGHT} fill="#4338ca" />
        <line x1="12" y1="55" x2="52" y2="55" stroke="#818cf8" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  if (variant === 'outline') {
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden>
        <rect x="0.5" y="0.5" width="63" height="63" rx="11.5" fill="none" stroke="#6366f1" strokeWidth="1.5" />
        <path d={CUBE_TOP}   fill="none" stroke="#6366f1" strokeWidth="2" strokeLinejoin="round" />
        <path d={CUBE_LEFT}  fill="none" stroke="#6366f1" strokeWidth="2" strokeLinejoin="round" />
        <path d={CUBE_RIGHT} fill="none" stroke="#6366f1" strokeWidth="2" strokeLinejoin="round" />
        <line x1="12" y1="55" x2="52" y2="55" stroke="#6366f1" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  // primary (default)
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden>
      <rect width="64" height="64" rx="12" fill="#6366f1" />
      <path d={CUBE_TOP}   fill="#fff" />
      <path d={CUBE_LEFT}  fill="#fff" opacity="0.85" />
      <path d={CUBE_RIGHT} fill="#fff" opacity="0.55" />
      <line x1="12" y1="55" x2="52" y2="55" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
    </svg>
  );
}

export function Logo({
  size = 28,
  showWordmark = true,
  variant = 'primary',
  className = '',
}: LogoProps) {
  const wordSize = Math.round(size * 0.65);
  const gap = Math.round(size * 0.28);
  const textColor = variant === 'light' ? '#0a0a0a' : '#ffffff';

  return (
    <div
      className={`inline-flex items-center ${className}`}
      style={{ gap, lineHeight: 1 }}
      aria-label="DevBase"
    >
      <Icon size={size} variant={variant} />
      {showWordmark && (
        <span
          className="font-mono font-semibold"
          style={{
            fontSize: wordSize,
            letterSpacing: '-0.03em',
            color: textColor,
            whiteSpace: 'nowrap',
          }}
        >
          dev<span style={{ color: '#6366f1' }}>/</span>base
        </span>
      )}
    </div>
  );
}
