'use client';
import { useEffect, useState } from 'react';

export function ScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const update = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(total > 0 ? window.scrollY / total : 0);
    };
    window.addEventListener('scroll', update, { passive: true });
    return () => window.removeEventListener('scroll', update);
  }, []);

  return (
    <div
      aria-hidden
      className="fixed top-0 left-0 z-[60] h-[3px] pointer-events-none"
      style={{
        width: `${progress * 100}%`,
        background: 'linear-gradient(90deg, #6366f1, #22c55e)',
        transition: 'width 0.08s linear',
      }}
    />
  );
}
