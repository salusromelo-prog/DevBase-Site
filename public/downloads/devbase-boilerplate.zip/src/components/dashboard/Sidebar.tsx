"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import { cn, getInitials } from "@/lib/utils";
import { LayoutDashboard, CreditCard, Settings, LogOut, BookOpen, Code2, Shield, Users } from "lucide-react";
import { Logo } from "@/components/Logo";

interface SidebarProps { user: any; profile: any; }

const NAV = [
  { href: "/dashboard", label: "início", icon: LayoutDashboard },
  { href: "/dashboard/planos", label: "planos", icon: CreditCard },
  { href: "/dashboard/equipe", label: "equipe", icon: Users },
  { href: "/dashboard/configuracoes", label: "config", icon: Settings },
];

const LINKS = [
  { href: "#", label: "docs", icon: BookOpen },
  { href: "#", label: "github", icon: Code2 },
];

export default function DashboardSidebar({ user, profile }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  const nome = profile?.full_name || user?.email?.split("@")[0] || "dev";
  const plano = profile?.plan || "free";

  return (
    <aside className="hidden md:flex w-56 flex-col h-screen sticky top-0"
      style={{ background: "var(--bg-2)", borderRight: "1px solid var(--border)" }}>
      {/* Logo */}
      <div className="px-4 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
        <Link href="/"><Logo size={24} /></Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-3 space-y-0.5">
        {NAV.map((item) => {
          const active = pathname === item.href;
          return (
            <Link key={item.href} href={item.href}
              className={cn("flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors", active ? "" : "hover:bg-white/5")}
              style={{
                background: active ? "var(--accent-bg)" : "transparent",
                color: active ? "var(--accent-2)" : "var(--text-2)",
                border: active ? "1px solid var(--accent-border)" : "1px solid transparent",
                fontFamily: "monospace",
              }}>
              <item.icon className="w-3.5 h-3.5 flex-shrink-0" />
              {item.label}
            </Link>
          );
        })}

        {profile?.role === "admin" && (() => {
          const active = pathname === "/dashboard/admin";
          return (
            <Link href="/dashboard/admin"
              className={cn("flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors", active ? "" : "hover:bg-white/5")}
              style={{
                background: active ? "rgba(239,68,68,0.1)" : "transparent",
                color: active ? "#f87171" : "var(--text-2)",
                border: active ? "1px solid rgba(239,68,68,0.25)" : "1px solid transparent",
                fontFamily: "monospace",
              }}>
              <Shield className="w-3.5 h-3.5 flex-shrink-0" />
              admin
            </Link>
          );
        })()}

        <div className="pt-4 pb-1 px-3">
          <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>// recursos</p>
        </div>
        {LINKS.map((item) => (
          <a key={item.href} href={item.href} target="_blank"
            className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors hover:bg-white/5"
            style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
            <item.icon className="w-3.5 h-3.5 flex-shrink-0" />
            {item.label}
          </a>
        ))}
      </nav>

      {/* User */}
      <div className="px-2 py-3" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg mb-0.5"
          style={{ background: "var(--bg-3)" }}>
          <div className="w-6 h-6 rounded-md flex items-center justify-center text-white flex-shrink-0"
            style={{ background: "var(--accent)", fontSize: "10px", fontFamily: "monospace", fontWeight: "700" }}>
            {getInitials(nome)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium truncate" style={{ fontFamily: "monospace" }}>{nome}</p>
            <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>{plano}</p>
          </div>
        </div>
        <button onClick={handleLogout}
          className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm w-full transition-colors hover:bg-red-500/10"
          style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          <LogOut className="w-3.5 h-3.5" />
          sair
        </button>
      </div>
    </aside>
  );
}
