"use client";

import { usePathname } from "next/navigation";
import { getInitials } from "@/lib/utils";
import { Bell } from "lucide-react";

const TITULOS: Record<string, string> = {
  "/dashboard": "início",
  "/dashboard/planos": "planos",
  "/dashboard/equipe": "equipe",
  "/dashboard/configuracoes": "configurações",
  "/dashboard/admin": "admin",
};

export default function DashboardHeader({ user, profile }: { user: any; profile: any }) {
  const pathname = usePathname();
  const titulo = TITULOS[pathname] || "dashboard";
  const nome = profile?.full_name || user?.email?.split("@")[0] || "dev";

  return (
    <header className="px-6 md:px-8 h-14 flex items-center justify-between sticky top-0 z-10"
      style={{ background: "rgba(10,10,10,0.8)", backdropFilter: "blur(12px)", borderBottom: "1px solid var(--border)" }}>
      <div className="flex items-center gap-2">
        <span className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>~/</span>
        <h2 className="text-sm font-medium" style={{ fontFamily: "monospace", color: "var(--text-2)" }}>{titulo}</h2>
      </div>
      <div className="flex items-center gap-2">
        <button className="w-8 h-8 rounded-lg flex items-center justify-center relative transition-colors hover:bg-white/5"
          style={{ border: "1px solid var(--border)", color: "var(--text-3)" }}>
          <Bell className="w-3.5 h-3.5" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full" style={{ background: "var(--accent)" }} />
        </button>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold"
          style={{ background: "var(--accent)", fontSize: "10px", fontFamily: "monospace" }}>
          {getInitials(nome)}
        </div>
      </div>
    </header>
  );
}
