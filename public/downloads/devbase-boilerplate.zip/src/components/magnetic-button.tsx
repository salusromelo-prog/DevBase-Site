'use client';
import { useRef, useState, MouseEvent, ReactNode, CSSProperties } from 'react';

export function MagneticButton({
  href,
  className,
  style,
  children,
}: {
  href: string;
  className?: string;
  style?: CSSProperties;
  children: ReactNode;
}) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const [active, setActive] = useState(false);

  const onMove = (e: MouseEvent<HTMLAnchorElement>) => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const rect = ref.current!.getBoundingClientRect();
    setTx(Math.max(-6, Math.min(6, (e.clientX - (rect.left + rect.width / 2)) * 0.3)));
    setTy(Math.max(-6, Math.min(6, (e.clientY - (rect.top + rect.height / 2)) * 0.3)));
    setActive(true);
  };

  const onLeave = () => { setTx(0); setTy(0); setActive(false); };

  return (
    <a
      ref={ref}
      href={href}
      className={className}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{
        ...style,
        transform: `translate(${tx}px, ${ty}px)`,
        transition: active
          ? 'transform 0.1s ease, opacity 0.2s'
          : 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1), opacity 0.2s',
      }}
    >
      {children}
    </a>
  );
}
