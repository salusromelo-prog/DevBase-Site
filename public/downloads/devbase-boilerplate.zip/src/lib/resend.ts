export const FROM_EMAIL =
  process.env.RESEND_FROM_EMAIL || "noreply@seudominio.com.br";

export const APP_NAME =
  process.env.NEXT_PUBLIC_APP_NAME || "DevBase";

export const APP_URL =
  process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
