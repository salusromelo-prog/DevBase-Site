// Planos disponíveis
export type Plan = "free" | "basico" | "pro" | "agencia";

// Status da assinatura
export type SubscriptionStatus =
  | "active"
  | "canceled"
  | "past_due"
  | "trialing"
  | "inactive";

// Perfil do usuário (tabela profiles no Supabase)
export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  plan: Plan;
  role: string | null;
  subscription_status: SubscriptionStatus;
  subscription_id: string | null;
  customer_id: string | null; // ID do cliente no Pagar.me
  created_at: string;
  updated_at: string;
}

// Plano com detalhes para exibição
export interface PlanDetails {
  id: Plan;
  name: string;
  price: number; // em centavos
  description: string;
  features: string[];
  highlighted?: boolean;
  pagarme_plan_id?: string;
}

// Configuração dos planos
export const PLANS: PlanDetails[] = [
  {
    id: "free",
    name: "Grátis",
    price: 0,
    description: "Para experimentar o kit",
    features: [
      "Acesso ao código base",
      "Auth por email",
      "Dashboard básico",
      "Suporte via GitHub Issues",
    ],
  },
  {
    id: "basico",
    name: "Básico",
    price: 29700, // R$ 297,00
    description: "Kit completo pra lançar seu SaaS",
    features: [
      "Tudo do Grátis",
      "Billing com Pagar.me (PIX, boleto, cartão)",
      "Email transacional (Resend)",
      "Landing page completa",
      "Admin panel",
      "Documentação PT-BR",
      "Acesso ao Discord",
      "Atualizações por 1 ano",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    price: 49700, // R$ 497,00
    description: "Para SaaS B2B e produtos com IA",
    features: [
      "Tudo do Básico",
      "Multi-tenancy (workspaces + times)",
      "Permissões por role (admin, membro)",
      "Módulo de IA (OpenAI + Anthropic)",
      "Rate limiting por usuário",
      "Controle de custo de tokens",
      "Suporte prioritário",
      "Atualizações vitalícias",
    ],
    highlighted: true,
  },
  {
    id: "agencia",
    name: "Agência",
    price: 99700, // R$ 997,00
    description: "Licença ilimitada pra projetos de clientes",
    features: [
      "Tudo do Pro",
      "Licença para projetos ilimitados",
      "Uso comercial irrestrito",
      "White-label (remova nossa marca)",
      "Onboarding 1:1 via videochamada",
      "Suporte via WhatsApp",
    ],
  },
];

// Usuário autenticado simplificado
export interface AuthUser {
  id: string;
  email: string;
  profile: Profile | null;
}
