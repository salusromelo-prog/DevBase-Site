"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Mail, AlertCircle, CheckCircle, ArrowLeft } from "lucide-react";
import { Logo } from "@/components/Logo";

export default function ResetSenhaPage() {
  const [email, setEmail] = useState("");
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [enviado, setEnviado] = useState(false);

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setCarregando(true);
    setErro("");

    const supabase = createClient();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/callback?next=/auth/nova-senha`,
    });

    if (error) {
      setErro("erro ao enviar email. verifique o endereço e tente novamente.");
      setCarregando(false);
      return;
    }

    setEnviado(true);
    setCarregando(false);
  }

  const inputStyle = {
    background: "var(--bg-3)",
    border: "1px solid var(--border)",
    borderRadius: "var(--radius)",
    color: "var(--text)",
    fontSize: "13px",
    fontFamily: "monospace",
    outline: "none",
    width: "100%",
    padding: "10px 12px 10px 36px",
    transition: "border-color .15s",
  };

  if (enviado) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
        <div className="max-w-sm w-full text-center">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-5"
            style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)" }}
          >
            <CheckCircle className="w-5 h-5" style={{ color: "#22c55e" }} />
          </div>
          <h2 className="font-bold text-xl mb-2" style={{ letterSpacing: "-0.03em" }}>email enviado!</h2>
          <p className="text-sm mb-1" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            verifique sua caixa de entrada em
          </p>
          <p className="text-sm mb-6" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>{email}</p>
          <Link
            href="/auth/login"
            className="text-xs transition-colors hover:text-white"
            style={{ color: "var(--text-3)", fontFamily: "monospace" }}
          >
            ← voltar para o login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
      <div className="absolute inset-0 grid-bg opacity-50 pointer-events-none" />
      <div className="w-full max-w-sm relative">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex mb-6"><Logo size={32} /></Link>
          <h1 className="font-bold text-2xl mb-1" style={{ letterSpacing: "-0.03em" }}>esqueceu a senha?</h1>
          <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            // enviaremos um link de recuperação
          </p>
        </div>

        <div className="rounded-xl p-6" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          {erro && (
            <div
              className="flex items-center gap-2 text-xs px-3 py-2.5 rounded-lg mb-4"
              style={{
                background: "rgba(239,68,68,0.08)",
                border: "1px solid rgba(239,68,68,0.2)",
                color: "#ef4444",
                fontFamily: "monospace",
              }}
            >
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
              {erro}
            </div>
          )}
          <form onSubmit={handleReset} className="space-y-3">
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
                email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--text-3)" }} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="seu@email.com.br"
                  style={inputStyle}
                  onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
                  onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={carregando}
              className="w-full py-2.5 rounded-lg text-sm font-medium transition-all hover:opacity-90 disabled:opacity-50 mt-1"
              style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}
            >
              {carregando ? "enviando..." : "enviar link →"}
            </button>
          </form>
        </div>

        <Link
          href="/auth/login"
          className="flex items-center justify-center gap-2 mt-5 text-xs transition-colors hover:text-white"
          style={{ color: "var(--text-3)", fontFamily: "monospace" }}
        >
          <ArrowLeft className="w-3 h-3" />
          voltar para o login
        </Link>
      </div>
    </div>
  );
}
