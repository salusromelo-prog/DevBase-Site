import { Suspense } from "react";
import CadastroForm from "./CadastroForm";

export default function CadastroPage() {
  return (
    <Suspense fallback={<div className="min-h-screen" style={{ background: "var(--bg)" }} />}>
      <CadastroForm />
    </Suspense>
  );
}