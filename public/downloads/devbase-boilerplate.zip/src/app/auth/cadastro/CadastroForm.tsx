"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Mail, Lock, User, Eye, EyeOff, AlertCircle, CheckCircle } from "lucide-react";
import { Logo } from "@/components/Logo";

export default function CadastroForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const plano = searchParams.get("plan") || "free";

  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState(false);

  async function handleCadastro(e: React.FormEvent) {
    e.preventDefault();
    setCarregando(true);
    setErro("");
    if (senha.length < 6) {
      setErro("a senha deve ter pelo menos 6 caracteres.");
      setCarregando(false);
      return;
    }
    const supabase = createClient();
    const { error } = await supabase.auth.signUp({
      email,
      password: senha,
      options: {
        data: { full_name: nome, plan: plano },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) {
      setErro(
        error.message.includes("already registered")
          ? "este email já está cadastrado. tente fazer login."
          : "erro ao criar conta. tente novamente."
      );
      setCarregando(false);
      return;
    }

    // Dispara email de boas-vindas (falha silenciosa — não bloqueia o cadastro)
    fetch("/api/emails/welcome", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome, email }),
    }).catch(() => {});

    setSucesso(true);
    setCarregando(false);
  }

  async function handleGoogleCadastro() {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    });
  }

  const inputStyle = {
    background: "var(--bg-3)",
    border: "1px solid var(--border)",
    borderRadius: "var(--radius)",
    color: "var(--text)",
    fontSize: "13px",
    fontFamily: "monospace",
    outline: "none",
    width: "100%",
    padding: "10px 12px 10px 36px",
    transition: "border-color .15s",
  };

  if (sucesso) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
        <div className="max-w-sm w-full text-center">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-5"
            style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)" }}>
            <CheckCircle className="w-5 h-5" style={{ color: "#22c55e" }} />
          </div>
          <h2 className="font-bold text-xl mb-2" style={{ letterSpacing: "-0.03em" }}>conta criada!</h2>
          <p className="text-sm mb-6" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            enviamos um email de confirmação para{" "}
            <span style={{ color: "var(--accent-2)" }}>{email}</span>
          </p>
          <Link href="/auth/login" className="text-xs transition-colors hover:text-white"
            style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
            ← voltar para o login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
      <div className="absolute inset-0 grid-bg opacity-50 pointer-events-none" />
      <div className="w-full max-w-sm relative">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex mb-6"><Logo size={32} /></Link>
          <h1 className="font-bold text-2xl mb-1" style={{ letterSpacing: "-0.03em" }}>criar sua conta</h1>
          <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            {plano !== "free" ? `// plano: ${plano}` : "// comece grátis, sem cartão"}
          </p>
        </div>

        <div className="rounded-xl p-6" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          <button onClick={handleGoogleCadastro}
            className="w-full flex items-center justify-center gap-2.5 py-2.5 rounded-lg text-sm transition-colors hover:bg-white/5 mb-5"
            style={{ border: "1px solid var(--border)", color: "var(--text-2)", fontFamily: "monospace" }}>
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            cadastrar com google
          </button>

          <div className="flex items-center gap-3 mb-5">
            <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
            <span className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>ou</span>
            <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
          </div>

          {erro && (
            <div className="flex items-center gap-2 text-xs px-3 py-2.5 rounded-lg mb-4"
              style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", color: "#ef4444", fontFamily: "monospace" }}>
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{erro}
            </div>
          )}

          <form onSubmit={handleCadastro} className="space-y-3">
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>nome</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--text-3)" }} />
                <input type="text" value={nome} onChange={e => setNome(e.target.value)} required
                  placeholder="seu nome" style={inputStyle}
                  onFocus={e => (e.target.style.borderColor = "var(--accent)")}
                  onBlur={e => (e.target.style.borderColor = "var(--border)")} />
              </div>
            </div>
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--text-3)" }} />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                  placeholder="seu@email.com.br" style={inputStyle}
                  onFocus={e => (e.target.style.borderColor = "var(--accent)")}
                  onBlur={e => (e.target.style.borderColor = "var(--border)")} />
              </div>
            </div>
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--text-3)" }} />
                <input type={mostrarSenha ? "text" : "password"} value={senha} onChange={e => setSenha(e.target.value)} required
                  placeholder="mínimo 6 caracteres" style={{ ...inputStyle, paddingRight: "36px" }}
                  onFocus={e => (e.target.style.borderColor = "var(--accent)")}
                  onBlur={e => (e.target.style.borderColor = "var(--border)")} />
                <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
                  className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: "var(--text-3)" }}>
                  {mostrarSenha ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={carregando}
              className="w-full py-2.5 rounded-lg text-sm font-medium transition-all hover:opacity-90 disabled:opacity-50 mt-1"
              style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
              {carregando ? "criando conta..." : "criar conta →"}
            </button>
          </form>

          <p className="text-xs text-center mt-4" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
            ao criar conta você concorda com os{" "}
            <a href="#" className="hover:text-white transition-colors" style={{ color: "var(--accent-2)" }}>termos</a>
            {" "}e{" "}
            <a href="#" className="hover:text-white transition-colors" style={{ color: "var(--accent-2)" }}>privacidade</a>
          </p>
        </div>

        <p className="text-center mt-5 text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          já tem conta?{" "}
          <Link href="/auth/login" className="transition-colors hover:text-white" style={{ color: "var(--accent-2)" }}>
            entrar
          </Link>
        </p>
      </div>
    </div>
  );
}
