"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Lock, Eye, EyeOff, AlertCircle, CheckCircle } from "lucide-react";
import { Logo } from "@/components/Logo";

export default function NovaSenhaPage() {
  const router = useRouter();
  const [senha, setSenha] = useState("");
  const [confirmar, setConfirmar] = useState("");
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState(false);

  async function handleNovaSenha(e: React.FormEvent) {
    e.preventDefault();
    setErro("");

    if (senha.length < 6) {
      setErro("a senha deve ter pelo menos 6 caracteres.");
      return;
    }
    if (senha !== confirmar) {
      setErro("as senhas não coincidem.");
      return;
    }

    setCarregando(true);
    const supabase = createClient();
    const { error } = await supabase.auth.updateUser({ password: senha });

    if (error) {
      setErro("erro ao atualizar a senha. o link pode ter expirado.");
      setCarregando(false);
      return;
    }

    setSucesso(true);
    setTimeout(() => router.push("/dashboard"), 2000);
  }

  const inputStyle = {
    background: "var(--bg-3)",
    border: "1px solid var(--border)",
    borderRadius: "var(--radius)",
    color: "var(--text)",
    fontSize: "13px",
    fontFamily: "monospace",
    outline: "none",
    width: "100%",
    padding: "10px 12px 10px 36px",
    transition: "border-color .15s",
  };

  if (sucesso) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
        <div className="max-w-sm w-full text-center">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-5"
            style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)" }}
          >
            <CheckCircle className="w-5 h-5" style={{ color: "#22c55e" }} />
          </div>
          <h2 className="font-bold text-xl mb-2" style={{ letterSpacing: "-0.03em" }}>senha atualizada!</h2>
          <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            redirecionando para o dashboard...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
      <div className="absolute inset-0 grid-bg opacity-50 pointer-events-none" />
      <div className="w-full max-w-sm relative">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex mb-6"><Logo size={32} /></Link>
          <h1 className="font-bold text-2xl mb-1" style={{ letterSpacing: "-0.03em" }}>nova senha</h1>
          <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            // escolha uma nova senha segura
          </p>
        </div>

        <div className="rounded-xl p-6" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          {erro && (
            <div
              className="flex items-center gap-2 text-xs px-3 py-2.5 rounded-lg mb-4"
              style={{
                background: "rgba(239,68,68,0.08)",
                border: "1px solid rgba(239,68,68,0.2)",
                color: "#ef4444",
                fontFamily: "monospace",
              }}
            >
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
              {erro}
            </div>
          )}
          <form onSubmit={handleNovaSenha} className="space-y-3">
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
                nova senha
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--text-3)" }} />
                <input
                  type={mostrarSenha ? "text" : "password"}
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  required
                  placeholder="mínimo 6 caracteres"
                  style={{ ...inputStyle, paddingRight: "36px" }}
                  onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
                  onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
                />
                <button
                  type="button"
                  onClick={() => setMostrarSenha(!mostrarSenha)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: "var(--text-3)" }}
                >
                  {mostrarSenha ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
                confirmar senha
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--text-3)" }} />
                <input
                  type={mostrarSenha ? "text" : "password"}
                  value={confirmar}
                  onChange={(e) => setConfirmar(e.target.value)}
                  required
                  placeholder="confirme a nova senha"
                  style={inputStyle}
                  onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
                  onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={carregando}
              className="w-full py-2.5 rounded-lg text-sm font-medium transition-all hover:opacity-90 disabled:opacity-50 mt-1"
              style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}
            >
              {carregando ? "salvando..." : "salvar nova senha →"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
