import { ImageResponse } from "next/og";

export const runtime = "edge";
export const size = { width: 180, height: 180 };
export const contentType = "image/png";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 180,
          height: 180,
          borderRadius: 34,
          background: "#6366f1",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <svg width="120" height="120" viewBox="0 0 64 64" fill="none">
          <path d="M32 12 L50 22 L32 32 L14 22 Z" fill="#ffffff" />
          <path d="M14 22 L32 32 L32 50 L14 40 Z" fill="#ffffff" fillOpacity="0.85" />
          <path d="M50 22 L32 32 L32 50 L50 40 Z" fill="#ffffff" fillOpacity="0.55" />
          <line x1="12" y1="55" x2="52" y2="55" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.6" />
        </svg>
      </div>
    ),
    { ...size }
  );
}
