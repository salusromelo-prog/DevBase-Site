import { Logo } from "@/components/Logo";
import { Check, Github, ArrowRight, Mail } from "lucide-react";

const STEPS = [
  "Verifique o email usado nesta compra",
  'Procure um email do GitHub com o assunto "You\'ve been invited to collaborate"',
  "Clique em Accept invitation",
  "Pronto — acesso liberado ao repositório do devbase",
];

export default function ObrigadoPage() {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--bg)" }}>
      {/* NAV */}
      <nav
        style={{ borderBottom: "1px solid var(--border)", background: "rgba(10,10,10,0.8)" }}
        className="px-6 h-14 flex items-center"
      >
        <Logo size={28} />
      </nav>

      {/* CONTENT */}
      <main className="flex-1 flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-lg">
          {/* Header */}
          <div className="mb-10 text-center">
            <div
              className="inline-flex w-14 h-14 rounded-full items-center justify-center mb-6"
              style={{ background: "var(--accent-bg)", border: "1px solid var(--accent-border)" }}
            >
              <Check className="w-6 h-6" style={{ color: "var(--accent-2)" }} />
            </div>
            <h1
              className="font-bold mb-3"
              style={{ fontSize: "clamp(1.8rem, 4vw, 2.5rem)", letterSpacing: "-0.03em" }}
            >
              Compra confirmada!
            </h1>
            <p className="text-base font-medium" style={{ color: "var(--accent-2)" }}>
              Seu acesso está a caminho.
            </p>
          </div>

          {/* Steps */}
          <div
            className="rounded-xl p-6 mb-6"
            style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}
          >
            <div
              className="text-xs mb-4"
              style={{ color: "var(--text-3)", fontFamily: "monospace" }}
            >
              // próximos passos
            </div>
            <ol className="space-y-4">
              {STEPS.map((step, i) => (
                <li key={i} className="flex items-start gap-4">
                  <span
                    className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{
                      background: "var(--accent-bg)",
                      border: "1px solid var(--accent-border)",
                      color: "var(--accent-2)",
                      fontFamily: "monospace",
                    }}
                  >
                    {i + 1}
                  </span>
                  <span className="text-sm leading-relaxed pt-0.5" style={{ color: "var(--text-2)" }}>
                    {step}
                  </span>
                </li>
              ))}
            </ol>
          </div>

          {/* Warning */}
          <div
            className="rounded-xl p-5 mb-8 flex items-start gap-3"
            style={{
              background: "rgba(99,102,241,0.08)",
              border: "1px solid var(--accent-border)",
            }}
          >
            <Mail className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "var(--accent-2)" }} />
            <p className="text-sm leading-relaxed" style={{ color: "var(--text-2)" }}>
              O convite é enviado para o email desta compra. Se sua conta GitHub usa um email diferente,
              envie um email para{" "}
              <a
                href="mailto:salusromelo@gmail.com"
                className="font-medium underline underline-offset-2"
                style={{ color: "var(--accent-2)" }}
              >
                salusromelo@gmail.com
              </a>{" "}
              informando o email correto.
            </p>
          </div>

          {/* CTA */}
          <a
            href="https://github.com/salusromelo-prog/DevBase/blob/main/DOCUMENTATION.md"
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full flex items-center justify-center gap-2 py-3 rounded-lg font-medium text-sm transition-all hover:opacity-90"
            style={{ background: "var(--accent)", color: "#fff" }}
          >
            <Github className="w-4 h-4" />
            Acessar documentação
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </a>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="py-5 px-6 text-center" style={{ borderTop: "1px solid var(--border)" }}>
        <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          feito com 💜 para devs brasileiros
        </p>
      </footer>
    </div>
  );
}
