"use client";

import { useEffect } from "react";
import Link from "next/link";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
      <div className="absolute inset-0 grid-bg opacity-50 pointer-events-none" />
      <div className="w-full max-w-sm text-center relative">
        <p className="text-xs mb-3" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// erro inesperado</p>
        <h1 className="font-bold text-2xl mb-2" style={{ letterSpacing: "-0.03em" }}>algo deu errado</h1>
        <p className="text-sm mb-6" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
          ocorreu um erro inesperado. tente novamente.
        </p>
        <div className="flex gap-3 justify-center">
          <button
            onClick={reset}
            className="px-5 py-2 rounded-lg text-sm font-medium transition-all hover:opacity-90"
            style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}
          >
            tentar novamente
          </button>
          <Link
            href="/"
            className="px-5 py-2 rounded-lg text-sm transition-colors hover:bg-white/5"
            style={{ border: "1px solid var(--border)", color: "var(--text-2)", fontFamily: "monospace" }}
          >
            início
          </Link>
        </div>
      </div>
    </div>
  );
}
