import type { Metadata } from "next";
import { DM_Sans, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const sans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  weight: ["300", "400", "500", "600", "700", "800"],
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["500", "600", "700"],
});

export const metadata: Metadata = {
  title: {
    default: "DevBase — Boilerplate Next.js para devs brasileiros",
    template: "%s | DevBase",
  },
  description:
    "Auth, billing PIX/boleto, dashboard pronto. Em PT-BR.",
  keywords: ["nextjs", "supabase", "pagarme", "saas", "boilerplate", "brasil"],
  openGraph: {
    type: "website",
    locale: "pt_BR",
    title: "DevBase",
    description: "Boilerplate Next.js para devs brasileiros",
    images: ["/og.png"],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className={`${sans.variable} ${mono.variable} font-sans`}>
        {children}
      </body>
    </html>
  );
}
