import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { formatDate, getInitials, truncate } from "@/lib/utils";
import { Shield, Users } from "lucide-react";
import CopyButton from "./CopyButton";
import type { Profile } from "@/types";

const PLAN_STYLES: Record<string, { bg: string; color: string; border: string }> = {
  free:    { bg: "var(--bg-4)",           color: "var(--text-3)",  border: "var(--border)" },
  basico:  { bg: "var(--accent-bg)",      color: "var(--accent-2)", border: "var(--accent-border)" },
  pro:     { bg: "rgba(168,85,247,0.1)",  color: "#c084fc",        border: "rgba(168,85,247,0.25)" },
  agencia: { bg: "rgba(251,146,60,0.1)",  color: "#fb923c",        border: "rgba(251,146,60,0.25)" },
};

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: currentProfile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user!.id)
    .single();

  if (currentProfile?.role !== "admin") redirect("/dashboard");

  const adminClient = createAdminClient();
  const { data: profiles } = await adminClient
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false });

  const allProfiles = (profiles ?? []) as Profile[];

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="text-xs mb-1" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          // painel administrativo
        </div>
        <h1 className="font-bold mb-1" style={{ fontSize: "1.75rem", letterSpacing: "-0.03em" }}>
          painel <span style={{ color: "#f87171" }}>admin</span>
        </h1>
        <p className="text-sm" style={{ color: "var(--text-2)" }}>
          gerencie todos os usuários cadastrados na plataforma.
        </p>
      </div>

      {/* Métricas rápidas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        {[
          { label: "total",   value: allProfiles.length },
          { label: "free",    value: allProfiles.filter((p) => p.plan === "free").length },
          { label: "pagantes", value: allProfiles.filter((p) => p.plan !== "free").length },
          { label: "admins",  value: allProfiles.filter((p) => p.role === "admin").length },
        ].map((m) => (
          <div key={m.label} className="p-4 rounded-xl" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
            <Users className="w-4 h-4 mb-3" style={{ color: "var(--text-3)" }} />
            <p className="font-bold text-lg" style={{ letterSpacing: "-0.02em", fontFamily: "monospace" }}>{m.value}</p>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>{m.label}</p>
          </div>
        ))}
      </div>

      {/* Tabela de usuários */}
      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)" }}>
        {/* Cabeçalho da tabela */}
        <div className="px-5 py-3 flex items-center gap-2" style={{ background: "var(--bg-2)", borderBottom: "1px solid var(--border)" }}>
          <Shield className="w-3.5 h-3.5" style={{ color: "#f87171" }} />
          <span className="text-xs font-medium" style={{ fontFamily: "monospace", color: "var(--text-2)" }}>
            usuários cadastrados
          </span>
          <span className="ml-auto text-xs px-2 py-0.5 rounded-md" style={{ background: "var(--bg-3)", color: "var(--text-3)", fontFamily: "monospace" }}>
            {allProfiles.length}
          </span>
        </div>

        {/* Grid header */}
        <div
          className="hidden md:grid px-5 py-2.5 text-xs"
          style={{
            gridTemplateColumns: "2fr 2fr 1fr 1fr auto",
            background: "var(--bg-3)",
            borderBottom: "1px solid var(--border)",
            color: "var(--text-3)",
            fontFamily: "monospace",
          }}
        >
          <span>usuário</span>
          <span>email</span>
          <span>cadastro</span>
          <span>plano</span>
          <span />
        </div>

        {/* Linhas */}
        <div style={{ background: "var(--bg)" }}>
          {allProfiles.length === 0 ? (
            <div className="px-5 py-10 text-center text-sm" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
              nenhum usuário encontrado.
            </div>
          ) : (
            allProfiles.map((profile, i) => {
              const nome = profile.full_name || profile.email?.split("@")[0] || "—";
              const plan = profile.plan ?? "free";
              const planStyle = PLAN_STYLES[plan] ?? PLAN_STYLES.free;

              return (
                <div
                  key={profile.id}
                  className="flex flex-col md:grid px-5 py-3.5 gap-2 md:gap-0 group hover:bg-white/[0.02] transition-colors"
                  style={{
                    gridTemplateColumns: "2fr 2fr 1fr 1fr auto",
                    borderBottom: i < allProfiles.length - 1 ? "1px solid var(--border)" : "none",
                    alignItems: "center",
                  }}
                >
                  {/* Usuário */}
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0 text-white font-bold"
                      style={{ background: "var(--accent)", fontSize: "10px", fontFamily: "monospace" }}
                    >
                      {getInitials(nome)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate" style={{ fontFamily: "monospace" }}>
                        {truncate(nome, 24)}
                      </p>
                      {profile.role === "admin" && (
                        <span className="text-xs" style={{ color: "#f87171", fontFamily: "monospace" }}>admin</span>
                      )}
                    </div>
                  </div>

                  {/* Email */}
                  <div className="flex items-center gap-1 min-w-0">
                    <span className="text-sm truncate" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
                      {truncate(profile.email ?? "—", 30)}
                    </span>
                    <CopyButton email={profile.email ?? ""} />
                  </div>

                  {/* Data */}
                  <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
                    {profile.created_at ? formatDate(profile.created_at) : "—"}
                  </p>

                  {/* Plano */}
                  <div>
                    <span
                      className="text-xs px-2 py-0.5 rounded-md"
                      style={{
                        background: planStyle.bg,
                        color: planStyle.color,
                        border: `1px solid ${planStyle.border}`,
                        fontFamily: "monospace",
                      }}
                    >
                      {plan}
                    </span>
                  </div>

                  {/* Ações (reservado) */}
                  <div />
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
