"use client";

import { useState } from "react";
import { Copy, Check } from "lucide-react";

export default function CopyButton({ email }: { email: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await navigator.clipboard.writeText(email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      onClick={handleCopy}
      title={copied ? "copiado!" : "copiar email"}
      className="p-1.5 rounded-md transition-colors hover:bg-white/5"
      style={{ color: copied ? "var(--green)" : "var(--text-3)" }}
    >
      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
    </button>
  );
}
