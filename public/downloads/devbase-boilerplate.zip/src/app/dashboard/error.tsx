"use client";

import { useEffect } from "react";

export default function DashboardError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="flex flex-col items-center justify-center h-full min-h-64 p-8 text-center">
      <p className="text-xs mb-3" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// erro</p>
      <h2 className="font-bold text-xl mb-2" style={{ letterSpacing: "-0.03em" }}>algo deu errado</h2>
      <p className="text-sm mb-5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
        erro ao carregar esta página. tente novamente.
      </p>
      <button
        onClick={reset}
        className="px-5 py-2 rounded-lg text-sm font-medium transition-all hover:opacity-90"
        style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}
      >
        tentar novamente
      </button>
    </div>
  );
}
