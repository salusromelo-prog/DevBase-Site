import { createClient } from "@/lib/supabase/server";
import { getInitials } from "@/lib/utils";
import { UserPlus, Crown, Lock } from "lucide-react";

export default async function EquipePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from("profiles").select("plan, full_name, email").eq("id", user!.id).single();
  const isPro = profile?.plan === "pro" || profile?.plan === "agencia";
  const nome = profile?.full_name || user?.email?.split("@")[0] || "dev";

  if (!isPro) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <div className="text-xs mb-1" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// equipe</div>
          <h1 className="font-bold text-2xl mb-1" style={{ letterSpacing: "-0.03em" }}>equipe</h1>
          <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>convide membros para colaborar.</p>
        </div>
        <div className="rounded-xl p-12 text-center" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
            style={{ background: "var(--bg-3)", border: "1px solid var(--border)" }}>
            <Lock className="w-5 h-5" style={{ color: "var(--text-3)" }} />
          </div>
          <h3 className="font-bold text-lg mb-2" style={{ letterSpacing: "-0.02em" }}>plano pro</h3>
          <p className="text-sm mb-6" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
            multi-tenancy e convite de membros disponíveis no plano pro.
          </p>
          <a href="/dashboard/planos"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all hover:opacity-90"
            style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
            <Crown className="w-3.5 h-3.5" /> ver plano pro
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <div className="text-xs mb-1" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// equipe</div>
          <h1 className="font-bold text-2xl" style={{ letterSpacing: "-0.03em" }}>equipe</h1>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all hover:opacity-90"
          style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
          <UserPlus className="w-3.5 h-3.5" /> convidar
        </button>
      </div>
      <div className="rounded-xl overflow-hidden" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
        <div className="px-5 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
          <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>// membros ativos (1)</p>
        </div>
        <div className="p-3">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg" style={{ background: "var(--bg-3)" }}>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0"
              style={{ background: "var(--accent)", fontSize: "11px", fontFamily: "monospace" }}>
              {getInitials(nome)}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium" style={{ fontFamily: "monospace" }}>{nome}</p>
              <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>{user?.email}</p>
            </div>
            <span className="text-xs px-2 py-1 rounded flex items-center gap-1"
              style={{ background: "var(--accent-bg)", color: "var(--accent-2)", border: "1px solid var(--accent-border)", fontFamily: "monospace" }}>
              <Crown className="w-3 h-3" /> admin
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
