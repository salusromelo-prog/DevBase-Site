import { createClient } from "@/lib/supabase/server";
import { PLANS } from "@/types";
import { ArrowRight, Terminal, Code2, CreditCard, Users, Zap } from "lucide-react";
import Link from "next/link";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user!.id).single();

  const nome = profile?.full_name || user?.email?.split("@")[0] || "dev";
  const plano = profile?.plan || "free";

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="text-xs mb-1" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          // bem-vindo de volta
        </div>
        <h1 className="font-bold mb-1" style={{ fontSize: "1.75rem", letterSpacing: "-0.03em" }}>
          olá, <span style={{ color: "var(--accent-2)" }}>{nome}</span>
        </h1>
        <p className="text-sm" style={{ color: "var(--text-2)" }}>seu ambiente está pronto. o que vamos construir hoje?</p>
      </div>

      {/* Upgrade banner */}
      {plano === "free" && (
        <div className="rounded-xl p-4 mb-6 flex items-center justify-between gap-4"
          style={{ background: "var(--accent-bg)", border: "1px solid var(--accent-border)" }}>
          <div>
            <p className="text-xs font-medium mb-0.5" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// plano free</p>
            <p className="text-sm" style={{ color: "var(--text)" }}>Configure seu ambiente e lance seu SaaS</p>
          </div>
          <Link href="/dashboard/planos"
            className="flex items-center gap-1.5 text-xs font-medium px-4 py-2 rounded-lg whitespace-nowrap transition-all hover:opacity-90"
            style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
            upgrade <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      )}

      {/* Métricas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        {[
          { icon: Zap, label: "projetos", value: "1" },
          { icon: Users, label: "membros", value: "1" },
          { icon: CreditCard, label: "plano", value: plano },
          { icon: Code2, label: "setup", value: "100%" },
        ].map((m, i) => (
          <div key={i} className="p-4 rounded-xl" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
            <m.icon className="w-4 h-4 mb-3" style={{ color: "var(--text-3)" }} />
            <p className="font-bold text-lg" style={{ letterSpacing: "-0.02em", fontFamily: "monospace" }}>{m.value}</p>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>{m.label}</p>
          </div>
        ))}
      </div>

      {/* Próximos passos */}
      <div className="rounded-xl overflow-hidden mb-6" style={{ border: "1px solid var(--border)" }}>
        <div className="px-5 py-3 flex items-center gap-2" style={{ background: "var(--bg-2)", borderBottom: "1px solid var(--border)" }}>
          <Terminal className="w-3.5 h-3.5" style={{ color: "var(--accent-2)" }} />
          <span className="text-xs font-medium" style={{ fontFamily: "monospace", color: "var(--text-2)" }}>próximos passos</span>
        </div>
        <div style={{ background: "var(--bg-3)" }}>
          {PROXIMOS_PASSOS.map((passo, i) => (
            <div key={i} className="flex items-center gap-4 px-5 py-3 group"
              style={{ borderBottom: i < PROXIMOS_PASSOS.length - 1 ? "1px solid var(--border)" : "none" }}>
              <div className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0 text-xs font-bold"
                style={{
                  background: passo.feito ? "var(--green-bg)" : "var(--bg-4)",
                  color: passo.feito ? "var(--green)" : "var(--text-3)",
                  border: `1px solid ${passo.feito ? "rgba(34,197,94,0.3)" : "var(--border)"}`,
                  fontFamily: "monospace",
                }}>
                {passo.feito ? "✓" : i + 1}
              </div>
              <div className="flex-1">
                <p className="text-sm" style={{ color: passo.feito ? "var(--text-3)" : "var(--text)", textDecoration: passo.feito ? "line-through" : "none", fontFamily: "monospace" }}>
                  {passo.titulo}
                </p>
                <p className="text-xs" style={{ color: "var(--text-3)" }}>{passo.desc}</p>
              </div>
              {!passo.feito && passo.href && (
                <Link href={passo.href} className="text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>
                  fazer →
                </Link>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Links rápidos */}
      <div className="grid sm:grid-cols-2 gap-3">
        {LINKS_RAPIDOS.map((link, i) => (
          <a key={i} href={link.href} target={link.externo ? "_blank" : undefined}
            className="flex items-center gap-3 p-4 rounded-xl transition-all hover:border-white/10 group"
            style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: "var(--bg-3)" }}>
              <link.icon className="w-4 h-4" style={{ color: "var(--text-3)" }} />
            </div>
            <div>
              <p className="text-sm font-medium" style={{ fontFamily: "monospace" }}>{link.titulo}</p>
              <p className="text-xs" style={{ color: "var(--text-3)" }}>{link.desc}</p>
            </div>
            <ArrowRight className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ color: "var(--text-3)" }} />
          </a>
        ))}
      </div>
    </div>
  );
}

const PROXIMOS_PASSOS = [
  { titulo: "criar conta no supabase", desc: "banco de dados e auth configurados", feito: true, href: null },
  { titulo: "configurar variáveis de ambiente", desc: "preencher o .env.local com suas chaves", feito: true, href: null },
  { titulo: "conectar o pagar.me", desc: "adicionar api key para billing", feito: false, href: "/dashboard/configuracoes" },
  { titulo: "configurar domínio", desc: "apontar seu domínio para a vercel", feito: false, href: "/dashboard/configuracoes" },
  { titulo: "personalizar o produto", desc: "trocar nome, cores e textos", feito: false, href: "/dashboard/configuracoes" },
  { titulo: "fazer o primeiro deploy", desc: "subir para produção na vercel", feito: false, href: "https://vercel.com" },
];

const LINKS_RAPIDOS = [
  { icon: Code2, titulo: "documentação", desc: "guia completo em pt-br", href: "#", externo: true },
  { icon: Terminal, titulo: "github", desc: "código-fonte completo", href: "#", externo: true },
  { icon: Users, titulo: "discord", desc: "comunidade de devs br", href: "#", externo: true },
  { icon: CreditCard, titulo: "fazer upgrade", desc: "desbloquear pagar.me e ia", href: "/dashboard/planos", externo: false },
];
