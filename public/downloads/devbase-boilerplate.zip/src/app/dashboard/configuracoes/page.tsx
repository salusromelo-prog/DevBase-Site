"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { User, Key, Bell, Trash2, CheckCircle } from "lucide-react";

export default function ConfiguracoesPage() {
  const [aba, setAba] = useState<"perfil" | "integrações" | "notificações">("perfil");
  const [nome, setNome] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [salvo, setSalvo] = useState(false);

  async function handleSalvarPerfil(e: React.FormEvent) {
    e.preventDefault();
    setSalvando(true);
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (user) await supabase.from("profiles").update({ full_name: nome }).eq("id", user.id);
    setSalvando(false);
    setSalvo(true);
    setTimeout(() => setSalvo(false), 3000);
  }

  const ABAS = [
    { id: "perfil", label: "perfil", icon: User },
    { id: "integrações", label: "integrações", icon: Key },
    { id: "notificações", label: "notificações", icon: Bell },
  ] as const;

  const inputStyle = {
    background: "var(--bg-3)",
    border: "1px solid var(--border)",
    borderRadius: "var(--radius)",
    color: "var(--text)",
    fontSize: "13px",
    fontFamily: "monospace",
    outline: "none",
    width: "100%",
    padding: "10px 12px",
    transition: "border-color .15s",
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <div className="text-xs mb-1" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// config</div>
        <h1 className="font-bold text-2xl mb-1" style={{ letterSpacing: "-0.03em" }}>configurações</h1>
        <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>gerencie suas preferências e integrações.</p>
      </div>

      {/* Abas */}
      <div className="flex gap-1 mb-6 p-1 rounded-lg w-fit" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
        {ABAS.map((a) => (
          <button key={a.id} onClick={() => setAba(a.id)}
            className="flex items-center gap-2 px-4 py-2 rounded-md text-xs font-medium transition-all"
            style={{
              background: aba === a.id ? "var(--bg-4)" : "transparent",
              color: aba === a.id ? "var(--text)" : "var(--text-3)",
              fontFamily: "monospace",
              border: aba === a.id ? "1px solid var(--border)" : "1px solid transparent",
            }}>
            <a.icon className="w-3.5 h-3.5" />
            {a.label}
          </button>
        ))}
      </div>

      {/* Perfil */}
      {aba === "perfil" && (
        <div className="rounded-xl p-6 space-y-5" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          {salvo && (
            <div className="flex items-center gap-2 text-xs px-3 py-2.5 rounded-lg"
              style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.2)", color: "#22c55e", fontFamily: "monospace" }}>
              <CheckCircle className="w-3.5 h-3.5" /> perfil atualizado!
            </div>
          )}
          <form onSubmit={handleSalvarPerfil} className="space-y-4">
            <div>
              <label className="text-xs block mb-1.5" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>nome completo</label>
              <input type="text" value={nome} onChange={e => setNome(e.target.value)}
                placeholder="seu nome completo" style={inputStyle}
                onFocus={e => (e.target.style.borderColor = "var(--accent)")}
                onBlur={e => (e.target.style.borderColor = "var(--border)")} />
            </div>
            <button type="submit" disabled={salvando}
              className="px-5 py-2 rounded-lg text-xs font-medium transition-all hover:opacity-90 disabled:opacity-50"
              style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
              {salvando ? "salvando..." : "salvar →"}
            </button>
          </form>

          <div className="pt-4" style={{ borderTop: "1px solid var(--border)" }}>
            <p className="text-xs font-medium mb-1 flex items-center gap-2" style={{ color: "#ef4444", fontFamily: "monospace" }}>
              <Trash2 className="w-3.5 h-3.5" /> zona de perigo
            </p>
            <p className="text-xs mb-3" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
              ação irreversível. todos os dados serão apagados permanentemente.
            </p>
            <button className="text-xs px-4 py-2 rounded-lg transition-colors hover:bg-red-500/10"
              style={{ color: "#ef4444", border: "1px solid rgba(239,68,68,0.2)", fontFamily: "monospace" }}>
              deletar conta
            </button>
          </div>
        </div>
      )}

      {/* Integrações */}
      {aba === "integrações" && (
        <div className="space-y-3">
          {INTEGRACOES.map((integ, i) => (
            <div key={i} className="flex items-center justify-between p-4 rounded-xl"
              style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
                  style={{ background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--accent-2)", fontFamily: "monospace" }}>
                  {integ.sigla}
                </div>
                <div>
                  <p className="text-sm font-medium" style={{ fontFamily: "monospace" }}>{integ.nome}</p>
                  <p className="text-xs" style={{ color: "var(--text-3)" }}>{integ.desc}</p>
                </div>
              </div>
              <button className="text-xs px-3 py-1.5 rounded-lg transition-all hover:opacity-90"
                style={{ background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--text-2)", fontFamily: "monospace" }}>
                configurar
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Notificações */}
      {aba === "notificações" && (
        <div className="rounded-xl overflow-hidden" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          {NOTIFICACOES.map((n, i) => (
            <div key={i} className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: i < NOTIFICACOES.length - 1 ? "1px solid var(--border)" : "none" }}>
              <div>
                <p className="text-sm font-medium" style={{ fontFamily: "monospace" }}>{n.titulo}</p>
                <p className="text-xs" style={{ color: "var(--text-3)" }}>{n.desc}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked={n.ativo} className="sr-only peer" />
                <div className="w-9 h-5 rounded-full peer-checked:bg-indigo-500 transition-colors"
                  style={{ background: "var(--bg-4)", border: "1px solid var(--border)" }} />
                <div className="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full peer-checked:translate-x-4 transition-transform shadow" />
              </label>
            </div>
          ))}
          <div className="px-5 py-4">
            <button className="text-xs px-4 py-2 rounded-lg transition-all hover:opacity-90"
              style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
              salvar preferências →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const INTEGRACOES = [
  { sigla: "PM", nome: "pagar.me", desc: "pagamentos com pix, boleto e cartão" },
  { sigla: "RS", nome: "resend", desc: "emails transacionais" },
  { sigla: "AI", nome: "openai", desc: "ia para seu produto (plano pro)" },
  { sigla: "GA", nome: "google analytics", desc: "métricas de acesso" },
];

const NOTIFICACOES = [
  { titulo: "novos pagamentos", desc: "email quando um pagamento for aprovado", ativo: true },
  { titulo: "novos membros", desc: "quando alguém entrar no workspace", ativo: true },
  { titulo: "atualizações do kit", desc: "avisos quando uma nova versão for lançada", ativo: true },
  { titulo: "emails de marketing", desc: "dicas e novidades do devbase", ativo: false },
];
