import { PLANS } from "@/types";
import { formatBRL } from "@/lib/utils";
import { Check, Zap } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function PlanosPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from("profiles").select("plan").eq("id", user!.id).single();
  const planoAtual = profile?.plan || "free";

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8">
        <div className="text-xs mb-1" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// planos</div>
        <h1 className="font-bold text-2xl mb-1" style={{ letterSpacing: "-0.03em" }}>planos e cobrança</h1>
        <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>pagamento único. sem mensalidade. atualizações inclusas.</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {PLANS.map((plan) => {
          const ativo = plan.id === planoAtual;
          return (
            <div key={plan.id} className="rounded-xl p-5 flex flex-col relative"
              style={{
                background: plan.highlighted ? "var(--accent)" : "var(--bg-2)",
                border: `1px solid ${ativo ? "var(--accent)" : plan.highlighted ? "transparent" : "var(--border)"}`,
              }}>
              {ativo && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1"
                  style={{ background: "var(--accent)", color: "#fff", fontFamily: "monospace" }}>
                  <Zap className="w-3 h-3" /> atual
                </div>
              )}
              {plan.highlighted && !ativo && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-semibold px-3 py-1 rounded-full"
                  style={{ background: "#fff", color: "var(--accent)", fontFamily: "monospace" }}>
                  popular
                </div>
              )}
              <p className="font-bold text-sm mb-1" style={{ fontFamily: "monospace", color: plan.highlighted && !ativo ? "#fff" : "var(--text)" }}>
                {plan.name.toLowerCase()}
              </p>
              <p className="text-xs mb-4" style={{ color: plan.highlighted && !ativo ? "rgba(255,255,255,0.6)" : "var(--text-3)", fontFamily: "monospace" }}>
                {plan.description}
              </p>
              <div className="mb-5">
                {plan.price === 0 ? (
                  <span className="font-bold text-2xl" style={{ letterSpacing: "-0.03em" }}>grátis</span>
                ) : (
                  <div>
                    <span className="font-bold text-2xl" style={{ letterSpacing: "-0.03em" }}>{formatBRL(plan.price / 100)}</span>
                    <span className="text-xs ml-1" style={{ color: plan.highlighted && !ativo ? "rgba(255,255,255,0.5)" : "var(--text-3)", fontFamily: "monospace" }}>único</span>
                  </div>
                )}
              </div>
              <ul className="space-y-2 mb-6 flex-1">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs">
                    <Check className="w-3.5 h-3.5 mt-0.5 flex-shrink-0"
                      style={{ color: plan.highlighted && !ativo ? "rgba(255,255,255,0.7)" : "var(--accent-2)" }} />
                    <span style={{ color: plan.highlighted && !ativo ? "rgba(255,255,255,0.8)" : "var(--text-2)" }}>{f}</span>
                  </li>
                ))}
              </ul>
              {ativo ? (
                <div className="w-full text-center py-2 rounded-lg text-xs font-medium"
                  style={{ background: "var(--bg-4)", color: "var(--text-3)", fontFamily: "monospace", border: "1px solid var(--border)" }}>
                  plano atual
                </div>
              ) : (
                <button className="w-full py-2 rounded-lg text-xs font-medium transition-all hover:opacity-90"
                  style={{
                    background: plan.highlighted ? "#fff" : "var(--bg-3)",
                    color: plan.highlighted ? "var(--accent)" : "var(--text)",
                    border: `1px solid ${plan.highlighted ? "transparent" : "var(--border)"}`,
                    fontFamily: "monospace",
                  }}>
                  {plan.price === 0 ? "grátis" : `comprar →`}
                </button>
              )}
            </div>
          );
        })}
      </div>

      <div className="rounded-xl p-5" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
        <p className="text-xs font-medium mb-3" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>// formas de pagamento</p>
        <div className="flex flex-wrap gap-2">
          {["cartão de crédito", "pix", "boleto bancário"].map((p) => (
            <span key={p} className="text-xs px-3 py-1.5 rounded-lg"
              style={{ background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--text-2)", fontFamily: "monospace" }}>
              {p}
            </span>
          ))}
        </div>
        <p className="text-xs mt-3" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          pagamentos processados pelo pagar.me. nota fiscal emitida automaticamente.
        </p>
      </div>
    </div>
  );
}
