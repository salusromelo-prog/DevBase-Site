import Image from "next/image";
import { ArrowRight, Check, Terminal, Shield, CreditCard, Code2, Globe, ChevronRight, Triangle, Database, Mail, Palette, Blocks, Cloud, Lock, LayoutDashboard, Github, GitBranch } from "lucide-react";
import { Logo } from "@/components/Logo";
import { ScrollProgress } from "@/components/scroll-progress";
import { SpotlightOverlay } from "@/components/spotlight-overlay";
import { MagneticButton } from "@/components/magnetic-button";
import { Reveal } from "@/components/reveal";
import { StatsCounter } from "@/components/stats-counter";
import { TiltCard } from "@/components/tilt-card";

export default function HomePage() {
  return (
    <div className="min-h-screen" style={{ background: "var(--bg)" }}>
      <ScrollProgress />

      {/* NAV */}
      <nav style={{ borderBottom: "1px solid var(--border)", background: "rgba(10,10,10,0.8)", backdropFilter: "blur(12px)" }}
        className="fixed top-0 left-0 right-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <Logo size={28} />
          <div className="hidden md:flex items-center gap-6 text-sm" style={{ color: "var(--text-2)" }}>
            <a href="#features" className="hover:text-white transition-colors">features</a>
            <a href="#pricing" className="hover:text-white transition-colors">pricing</a>
            <a href="#stack" className="hover:text-white transition-colors">stack</a>
          </div>
          <div className="flex items-center gap-3">
            <a href="https://pay.kiwify.com.br/d4yYNFy"
              className="text-sm font-medium px-4 py-1.5 rounded-md transition-all hover:opacity-90"
              style={{ background: "var(--accent)", color: "#fff" }}>
              Comprar agora — R$ 147
            </a>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="pt-32 pb-24 px-6 relative overflow-hidden grid-bg">
        {/* Aurora orbs + floating particles */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] opacity-20"
            style={{ background: "radial-gradient(ellipse, #6366f1 0%, transparent 70%)" }} />
          <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[350px] h-[350px] opacity-[0.08]"
            style={{ background: "radial-gradient(ellipse, #6366f1 0%, transparent 70%)" }} />
          <div className="absolute top-1/2 right-0 -translate-y-1/2 w-[350px] h-[350px] opacity-[0.04]"
            style={{ background: "radial-gradient(ellipse, #22c55e 0%, transparent 70%)" }} />
          {PARTICLES.map((p, i) => (
            <span key={i} className="particle" style={{
              left: p.left, top: p.top,
              width: p.size, height: p.size,
              "--p-op": p.op, "--p-dur": `${p.dur}s`, "--p-delay": `${p.delay}s`,
              opacity: p.op,
            } as React.CSSProperties} />
          ))}
        </div>
        <SpotlightOverlay />

        <div className="max-w-4xl mx-auto relative" style={{ zIndex: 2 }}>
          {/* Badge */}
          <div className="animate-fade-up flex items-center gap-2 mb-8 w-fit">
            <div className="flex items-center gap-2 text-xs px-3 py-1.5 rounded-full"
              style={{ background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--text-2)", fontFamily: "monospace" }}>
              <span className="w-1.5 h-1.5 rounded-full animate-pulse-slow" style={{ background: "var(--green)" }} />
              v1.0 — agora disponível para devs BR
              <ChevronRight className="w-3 h-3" />
            </div>
          </div>

          {/* Heading */}
          <h1 className="animate-fade-up-2 font-bold mb-6" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)", letterSpacing: "-0.04em" }}>
            <span style={{ color: "var(--text)" }}>do repositório</span><br />
            <span style={{ color: "var(--text)" }}>ao mercado.</span><br />
            <span className="text-shimmer">em dias.</span>
          </h1>

          <p className="animate-fade-up-3 text-lg mb-10 max-w-xl" style={{ color: "var(--text-2)", lineHeight: "1.7" }}>
            O único boilerplate Next.js com <strong style={{ color: "var(--text)" }}>PIX, boleto e Pagar.me nativos</strong>.
            Auth, billing e deploy — documentação 100% em português.
          </p>

          {/* Promo badge */}
          <div className="animate-fade-up-4 mb-4 w-fit">
            <div className="promo-badge-outer">
              <span className="text-xs px-3 py-1.5 rounded-full promo-badge-inner"
                style={{ background: "rgba(99,102,241,0.1)", color: "#818cf8", fontFamily: "monospace" }}>
                🔥 Promoção de lançamento — 50% off
              </span>
            </div>
          </div>

          <div className="animate-fade-up-4 flex flex-col sm:flex-row gap-3 mb-16">
            <MagneticButton
              href="https://pay.kiwify.com.br/d4yYNFy"
              className="cta-glow group flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-medium hover:opacity-90"
              style={{ background: "var(--accent)", color: "#fff" }}>
              Comprar agora — R$ 147{" "}
              <span className="text-sm line-through" style={{ color: "rgba(255,255,255,0.55)", fontWeight: "normal" }}>R$ 297</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </MagneticButton>
            <a href="#pricing"
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-medium transition-all hover:border-white/20"
              style={{ border: "1px solid var(--border)", color: "var(--text-2)" }}>
              ver preços
            </a>
          </div>

          {/* Stats counter */}
          <StatsCounter />

          {/* Terminal preview */}
          <div className="animate-fade-up-4 rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "var(--bg-2)" }}>
            <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: "1px solid var(--border)", background: "var(--bg-3)" }}>
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full" style={{ background: "#ef4444" }} />
                <div className="w-3 h-3 rounded-full" style={{ background: "#f59e0b" }} />
                <div className="w-3 h-3 rounded-full" style={{ background: "#22c55e" }} />
              </div>
              <span className="text-xs ml-2" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>terminal</span>
            </div>
            <div className="p-5" style={{ fontFamily: "monospace", fontSize: "13px" }}>
              <div className="type-line-1 flex gap-3 mb-1.5">
                <span style={{ color: "var(--accent-2)" }}>$</span>
                <span style={{ color: "var(--text-2)" }}>git clone devbase/starter-kit && cd meu-saas</span>
              </div>
              <div className="type-line-2 flex gap-3 mb-1.5">
                <span style={{ color: "var(--accent-2)" }}>$</span>
                <span style={{ color: "var(--text-2)" }}>cp .env.example .env.local <span style={{ color: "var(--text-3)" }}># cole suas chaves</span></span>
              </div>
              <div className="type-line-3 flex gap-3 mb-4">
                <span style={{ color: "var(--accent-2)" }}>$</span>
                <span style={{ color: "var(--text-2)" }}>npm install && npm run dev<span className="cursor-blink" /></span>
              </div>
              <div style={{ color: "var(--text-3)", lineHeight: "1.8" }}>
                <div><span style={{ color: "var(--green)" }}>✓</span> auth configurado — login, cadastro, oauth</div>
                <div><span style={{ color: "var(--green)" }}>✓</span> pagar.me conectado — pix, boleto, cartão</div>
                <div><span style={{ color: "var(--green)" }}>✓</span> dashboard rodando em localhost:3000</div>
                <div style={{ color: "var(--accent-2)", marginTop: "4px" }}>→ pronto pra construir seu produto 🚀</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <div style={{ borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)", background: "var(--bg-2)" }} className="py-4">
        <div className="max-w-6xl mx-auto px-6 flex flex-wrap items-center justify-center gap-8 text-sm" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
          {["Next.js 14", "Supabase", "Pagar.me", "Tailwind CSS", "TypeScript", "Vercel"].map(t => (
            <span key={t} className="hover:text-white transition-colors cursor-default">{t}</span>
          ))}
        </div>
      </div>

      {/* FEATURES */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <Reveal>
            <div className="mb-14">
              <div className="text-xs mb-3" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// features</div>
              <h2 className="font-bold mb-4" style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}>
                Tudo que você precisa.<br />
                <span style={{ color: "var(--text-2)" }}>Nada que você não precisa.</span>
              </h2>
            </div>
          </Reveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map((f, i) => (
              <Reveal key={i} delay={i * 100}>
                <TiltCard className="h-full">
                  <div className="group p-5 rounded-xl card-glow gradient-border-card h-full"
                    style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-4 transition-colors"
                      style={{ background: "var(--bg-3)" }}>
                      <f.icon className="w-4 h-4" style={{ color: "var(--accent-2)" }} />
                    </div>
                    <h3 className="font-semibold text-sm mb-1.5" style={{ letterSpacing: "-0.01em" }}>{f.title}</h3>
                    <p className="text-sm leading-relaxed" style={{ color: "var(--text-2)" }}>{f.description}</p>
                    {f.badge && (
                      <span className="mt-3 inline-block text-xs px-2 py-0.5 rounded"
                        style={{ background: "var(--accent-bg)", color: "var(--accent-2)", border: "1px solid var(--accent-border)", fontFamily: "monospace" }}>
                        {f.badge}
                      </span>
                    )}
                  </div>
                </TiltCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PREVIEW */}
      <section id="preview" className="py-24 px-6" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="max-w-6xl mx-auto">
          <Reveal>
            <div className="mb-14">
              <div className="text-xs mb-3" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// preview</div>
              <h2 className="font-bold mb-3" style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}>
                veja o que você recebe.
              </h2>
              <p className="text-sm" style={{ color: "var(--text-2)", fontFamily: "monospace" }}>
                dashboard completo, pronto pra personalizar
              </p>
            </div>
          </Reveal>

          <Reveal>
            <div className="rounded-xl overflow-hidden mb-4"
              style={{ border: "1px solid var(--border)", background: "var(--bg-2)" }}>
              <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: "1px solid var(--border)", background: "var(--bg-3)" }}>
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ background: "#ef4444" }} />
                  <div className="w-3 h-3 rounded-full" style={{ background: "#f59e0b" }} />
                  <div className="w-3 h-3 rounded-full" style={{ background: "#22c55e" }} />
                </div>
                <span className="text-xs ml-2" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>dashboard</span>
              </div>
              <Image
                src="/preview-dashboard.png"
                alt="Dashboard DevBase"
                width={1440}
                height={900}
                className="w-full h-auto"
                priority
              />
            </div>
          </Reveal>

          <Reveal delay={100}>
            <div className="rounded-xl overflow-hidden"
              style={{ border: "1px solid var(--border)", background: "var(--bg-2)" }}>
              <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: "1px solid var(--border)", background: "var(--bg-3)" }}>
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ background: "#ef4444" }} />
                  <div className="w-3 h-3 rounded-full" style={{ background: "#f59e0b" }} />
                  <div className="w-3 h-3 rounded-full" style={{ background: "#22c55e" }} />
                </div>
                <span className="text-xs ml-2" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>auth</span>
              </div>
              <Image
                src="/preview-login.png"
                alt="Login DevBase"
                width={1440}
                height={900}
                className="w-full h-auto"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* STACK */}
      <section id="stack" className="py-24 px-6" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="max-w-6xl mx-auto">
          <Reveal>
            <div className="mb-14">
              <div className="text-xs mb-3" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// stack</div>
              <h2 className="font-bold" style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}>
                Stack moderna.<br />
                <span style={{ color: "var(--text-2)" }}>Escolhida a dedo.</span>
              </h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {STACK.map((s, i) => (
              <Reveal key={i} delay={i * 100}>
                <div className="p-4 rounded-xl card-glow group h-full"
                  style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
                  <div className="w-8 h-8 rounded-md flex items-center justify-center mb-3 text-xs font-bold"
                    style={{ background: "var(--bg-4)", color: "var(--accent-2)", fontFamily: "monospace", border: "1px solid var(--border)" }}>
                    <s.icon className="w-4 h-4" />
                  </div>
                  <div className="font-semibold text-sm mb-0.5" style={{ fontFamily: "monospace" }}>{s.name}</div>
                  <div className="text-xs" style={{ color: "var(--text-3)" }}>{s.role}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="py-24 px-6" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="max-w-6xl mx-auto">
          <Reveal>
            <div className="mb-14">
              <div className="text-xs mb-3" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// pricing</div>
              <h2 className="font-bold mb-3" style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}>
                Tudo que você precisa.<br />
                <span style={{ color: "var(--text-2)" }}>Sem mensalidade, sem surpresa.</span>
              </h2>
              <p style={{ color: "var(--text-2)" }}>Um kit completo pra você sair do zero e lançar seu SaaS em dias, não meses.</p>
            </div>
          </Reveal>
          <div className="flex justify-center">
            <Reveal>
              <div className="relative rounded-xl p-8 flex flex-col w-full max-w-sm card-glow"
                style={{ background: "var(--accent)", border: "1px solid transparent" }}>
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-semibold px-3 py-1 rounded-full"
                  style={{ background: "#fff", color: "var(--accent)", fontFamily: "monospace" }}>
                  acesso vitalício
                </div>
                <div className="font-bold text-sm mb-1 text-white" style={{ fontFamily: "monospace" }}>devbase</div>
                <div className="text-xs mb-6" style={{ color: "rgba(255,255,255,0.7)" }}>
                  Tudo incluso. Compre uma vez, use para sempre.
                </div>
                <div className="mb-6">
                  <span className="font-bold text-3xl" style={{ letterSpacing: "-0.03em", color: "#22c55e" }}>R$ 147,00</span>
                  <span className="text-sm ml-2 line-through" style={{ color: "rgba(255,255,255,0.5)", fontFamily: "monospace" }}>R$ 297</span>
                  <span className="text-xs ml-2" style={{ color: "rgba(255,255,255,0.6)", fontFamily: "monospace" }}>pagamento único</span>
                </div>
                <ul className="space-y-2.5 mb-8 flex-1">
                  {[
                    "Código-fonte completo (Next.js 14 + TypeScript)",
                    "Autenticação com Google OAuth e email",
                    "Billing integrado com Pagar.me (PIX, boleto, cartão)",
                    "Email transacional com Resend",
                    "Dashboard e Admin panel prontos",
                    "Landing page de alta conversão inclusa",
                    "Documentação completa em PT-BR",
                    "Atualizações por 1 ano",
                  ].map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs">
                      <Check className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" style={{ color: "rgba(255,255,255,0.8)" }} />
                      <span style={{ color: "rgba(255,255,255,0.85)" }}>{f}</span>
                    </li>
                  ))}
                </ul>
                <a href="https://pay.kiwify.com.br/d4yYNFy"
                  className="w-full text-center py-3 rounded-lg text-sm font-medium transition-all hover:opacity-90"
                  style={{ background: "#fff", color: "var(--accent)", fontFamily: "monospace" }}>
                  comprar agora →
                </a>
                <div className="mt-3 flex items-center justify-center gap-1.5 text-xs" style={{ color: "rgba(255,255,255,0.55)", fontFamily: "monospace" }}>
                  <Lock className="w-3 h-3 flex-shrink-0" />
                  <span>Pagamento seguro via Kiwify · Acesso imediato após a compra</span>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* GARANTIA */}
      <section className="py-16 px-6" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="max-w-2xl mx-auto text-center">
          <Reveal>
            <div className="inline-flex flex-col items-center gap-4 px-8 py-8 rounded-2xl"
              style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
              <div className="w-16 h-16 rounded-full flex items-center justify-center"
                style={{ background: "var(--green-bg)", border: "1px solid rgba(34,197,94,0.2)" }}>
                <Shield className="w-7 h-7" style={{ color: "var(--green)" }} />
              </div>
              <div>
                <div className="text-xs mb-2" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// garantia</div>
                <h3 className="font-bold text-xl mb-2" style={{ letterSpacing: "-0.02em" }}>
                  7 dias de garantia incondicional
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "var(--text-2)", maxWidth: "420px" }}>
                  Se por qualquer motivo você não ficar satisfeito nos primeiros 7 dias após a compra,
                  devolvemos 100% do seu dinheiro. Sem perguntas, sem burocracia.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="max-w-2xl mx-auto text-center">
          <Reveal>
            <div className="text-xs mb-4" style={{ color: "var(--accent-2)", fontFamily: "monospace" }}>// pronto pra começar?</div>
            <h2 className="font-bold mb-4" style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}>
              Pare de reinventar a roda.<br />
              <span style={{ color: "var(--text-2)" }}>Foque no que importa.</span>
            </h2>
            <p className="mb-8" style={{ color: "var(--text-2)" }}>
              Junte-se a centenas de devs brasileiros que já economizaram semanas de setup.
            </p>
            <div className="flex justify-center">
              <MagneticButton
                href="https://pay.kiwify.com.br/d4yYNFy"
                className="cta-glow inline-flex items-center gap-2 px-8 py-3 rounded-lg font-medium hover:opacity-90"
                style={{ background: "var(--accent)", color: "#fff" }}>
                Comprar agora — R$ 147
                <ArrowRight className="w-4 h-4" />
              </MagneticButton>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-6 px-6" style={{ borderTop: "1px solid var(--border)" }}>
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <Logo size={22} />
          <p className="text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
            feito com 💜 para devs brasileiros
          </p>
          <div className="flex gap-5 text-xs" style={{ color: "var(--text-3)", fontFamily: "monospace" }}>
            {["docs", "github", "discord"].map(l => (
              <a key={l} href="#" className="hover:text-white transition-colors">{l}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}

const PARTICLES = [
  { left: "8%",  top: "18%", size: 2, dur: 6.1, delay: 0,   op: 0.15 },
  { left: "82%", top: "12%", size: 3, dur: 5.3, delay: 1.2, op: 0.20 },
  { left: "23%", top: "62%", size: 2, dur: 7.4, delay: 2.1, op: 0.10 },
  { left: "67%", top: "44%", size: 2, dur: 8.0, delay: 0.5, op: 0.25 },
  { left: "44%", top: "82%", size: 3, dur: 4.7, delay: 1.8, op: 0.15 },
  { left: "91%", top: "68%", size: 2, dur: 6.5, delay: 3.0, op: 0.10 },
  { left: "14%", top: "87%", size: 3, dur: 5.8, delay: 2.6, op: 0.20 },
  { left: "56%", top: "8%",  size: 2, dur: 7.1, delay: 0.9, op: 0.15 },
  { left: "33%", top: "33%", size: 2, dur: 6.3, delay: 4.0, op: 0.20 },
  { left: "76%", top: "91%", size: 3, dur: 5.1, delay: 1.4, op: 0.10 },
  { left: "4%",  top: "52%", size: 2, dur: 8.2, delay: 3.7, op: 0.25 },
  { left: "93%", top: "28%", size: 2, dur: 4.5, delay: 0.3, op: 0.15 },
  { left: "38%", top: "22%", size: 3, dur: 7.6, delay: 5.0, op: 0.12 },
  { left: "61%", top: "71%", size: 2, dur: 5.5, delay: 2.3, op: 0.18 },
];

const FEATURES = [
  { icon: CreditCard, title: "billing 100% brasileiro", description: "Pagar.me integrado com PIX, boleto e cartão. Webhook pronto. Inexistente em qualquer kit gringo.", badge: "🇧🇷 exclusivo BR" },
  { icon: Shield, title: "auth completo", description: "Login, cadastro, OAuth Google/GitHub, magic link e reset de senha. Middleware de proteção incluso." },
  { icon: Code2, title: "docs em pt-br", description: "Guias completos em português com tutoriais em vídeo. Sem precisar traduzir nada.", badge: "🇧🇷 pt-br" },
  { icon: Terminal, title: "deploy em 1 clique", description: "Vercel configurada e pronta. Do código ao ar em menos de 5 minutos." },
  { icon: Globe, title: "email transacional", description: "Resend integrado com templates de boas-vindas e notificações em PT-BR." },
  { icon: Code2, title: "typescript strict", description: "100% tipado. Melhor DX e compatível com Cursor, Copilot e outros AI coding tools." },
  { icon: Shield, title: "supabase nativo", description: "Auth, banco de dados, storage e realtime — tudo configurado e pronto para usar." },
  { icon: LayoutDashboard, title: "dashboard pronto", description: "Sidebar, header, métricas e navegação. Pronto pra você personalizar e lançar." },
  { icon: GitBranch, title: "código limpo", description: "Estrutura de pastas organizada, componentes reutilizáveis e padrões prontos pra escalar." },
];

const STACK = [
  { icon: Triangle, name: "Next.js 14", role: "framework" },
  { icon: Database, name: "Supabase", role: "auth + db" },
  { icon: CreditCard, name: "Pagar.me", role: "billing br" },
  { icon: Mail, name: "Resend", role: "emails" },
  { icon: Palette, name: "Tailwind", role: "estilo" },
  { icon: Blocks, name: "shadcn/ui", role: "componentes" },
  { icon: Cloud, name: "Vercel", role: "deploy" },
  { icon: Github, name: "GitHub", role: "privado" },
];
