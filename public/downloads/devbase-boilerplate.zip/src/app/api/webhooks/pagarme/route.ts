import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

// Cliente admin (bypassa RLS)
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { type, data } = body;

    // Verifica assinatura do webhook (produção)
    // const signature = request.headers.get("x-hub-signature");
    // TODO: validar assinatura com PAGARME_WEBHOOK_SECRET

    switch (type) {
      case "order.paid": {
        // Pagamento aprovado — ativa o plano do usuário
        const { customer, items, id: orderId } = data;
        const userEmail = customer?.email;
        const planId = items?.[0]?.code; // código do plano no item

        if (userEmail && planId) {
          // Busca usuário pelo email
          const { data: profile } = await supabaseAdmin
            .from("profiles")
            .select("id")
            .eq("email", userEmail)
            .single();

          if (profile) {
            // Atualiza plano do usuário
            await supabaseAdmin
              .from("profiles")
              .update({
                plan: planId,
                subscription_status: "active",
                subscription_id: orderId,
              })
              .eq("id", profile.id);

            // Registra pagamento
            await supabaseAdmin.from("payments").insert({
              user_id: profile.id,
              pagarme_order_id: orderId,
              plan: planId,
              amount: data.amount,
              status: "paid",
              payment_method: data.charges?.[0]?.payment_method || "unknown",
            });
          }
        }
        break;
      }

      case "order.canceled":
      case "charge.refunded": {
        // Pagamento cancelado/reembolsado — revoga plano
        const userEmail = data?.customer?.email;
        if (userEmail) {
          await supabaseAdmin
            .from("profiles")
            .update({ plan: "free", subscription_status: "canceled" })
            .eq("email", userEmail);
        }
        break;
      }
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Webhook Pagar.me erro:", error);
    return NextResponse.json({ error: "Webhook error" }, { status: 400 });
  }
}
