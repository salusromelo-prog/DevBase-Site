import { NextResponse } from "next/server";

const GITHUB_REPO = "salusromelo-prog/saas-kit-br";

async function addGitHubCollaborator(email: string): Promise<{
  status: "invited" | "already_collaborator" | "user_not_found" | "error";
  username?: string;
  error?: string;
}> {
  const token = process.env.GITHUB_TOKEN;
  if (!token) return { status: "error", error: "GITHUB_TOKEN not configured" };

  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  };

  // Busca usuário pelo email público no GitHub
  const searchRes = await fetch(
    `https://api.github.com/search/users?q=${encodeURIComponent(email)}+in:email`,
    { headers }
  );

  if (!searchRes.ok) {
    return { status: "error", error: `GitHub search failed: ${searchRes.status}` };
  }

  const searchData = await searchRes.json();

  if (!searchData.items?.length) {
    // Email não está público no perfil GitHub do comprador
    return { status: "user_not_found" };
  }

  const username = searchData.items[0].login as string;

  // Envia convite de colaborador com permissão de leitura (pull)
  const inviteRes = await fetch(
    `https://api.github.com/repos/${GITHUB_REPO}/collaborators/${username}`,
    { method: "PUT", headers, body: JSON.stringify({ permission: "pull" }) }
  );

  // 201 = convite enviado, 204 = já era colaborador
  if (inviteRes.status === 201) return { status: "invited", username };
  if (inviteRes.status === 204) return { status: "already_collaborator", username };

  const errBody = await inviteRes.json().catch(() => ({}));
  return { status: "error", error: errBody.message ?? `GitHub API ${inviteRes.status}` };
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Kiwify envia order_status: "paid" para compras aprovadas
    if (body.order_status !== "paid") {
      return NextResponse.json({ received: true, skipped: true, order_status: body.order_status });
    }

    const email: string | undefined = body.customer?.email;
    if (!email) {
      console.error("Kiwify webhook: payload sem customer.email", body);
      return NextResponse.json({ error: "Missing customer email" }, { status: 400 });
    }

    const result = await addGitHubCollaborator(email);

    if (result.status === "user_not_found") {
      // Retorna 200 para o Kiwify não retentar — o comprador provavelmente
      // não tem email público no GitHub ou ainda não tem conta
      console.warn(`Kiwify webhook: GitHub user not found for email ${email}`);
      return NextResponse.json({ received: true, github_status: "user_not_found", email });
    }

    if (result.status === "error") {
      console.error(`Kiwify webhook: GitHub error for ${email}:`, result.error);
      return NextResponse.json({ error: result.error }, { status: 500 });
    }

    console.log(`Kiwify webhook: GitHub ${result.status} → ${result.username} (${email})`);
    return NextResponse.json({
      received: true,
      github_status: result.status,
      username: result.username,
      email,
    });
  } catch (error) {
    console.error("Webhook Kiwify erro:", error);
    return NextResponse.json({ error: "Webhook error" }, { status: 400 });
  }
}
