export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { FROM_EMAIL, APP_NAME, APP_URL } from "@/lib/resend";
import { emailBoasVindas } from "@/emails/welcome";

export async function POST(request: NextRequest) {
  const resend = new Resend(process.env.RESEND_API_KEY);

  const { nome, email } = await request.json();

  if (!nome || !email) {
    return NextResponse.json({ error: "nome e email são obrigatórios" }, { status: 400 });
  }

  const { error } = await resend.emails.send({
    from: FROM_EMAIL,
    to: email,
    subject: `Bem-vindo ao ${APP_NAME} 🚀`,
    html: emailBoasVindas({ nome, dashboardUrl: `${APP_URL}/dashboard` }),
  });

  if (error) {
    console.error("[resend] erro ao enviar boas-vindas:", error);
    return NextResponse.json({ error: "falha ao enviar email" }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
