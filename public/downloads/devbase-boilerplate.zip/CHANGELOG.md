# Changelog

## v1.0.0 — lançamento inicial
- Autenticação com email e Google OAuth
- Dashboard completo com sidebar e métricas
- Admin panel
- Billing com Pagar.me
- Email transacional com Resend
- Documentação completa em PT-BR
- Deploy configurado na Vercel
