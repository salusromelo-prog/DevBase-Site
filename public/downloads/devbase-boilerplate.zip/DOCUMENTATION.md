# Documentação DevBase

> Boilerplate Next.js 14 para SaaS brasileiro — autenticação, billing com PIX/boleto, dashboard pronto e documentação 100% em PT-BR.

---

## Índice

1. [Visão Geral do Produto](#1-visão-geral-do-produto)
2. [Pré-requisitos](#2-pré-requisitos)
3. [Guia de Instalação](#3-guia-de-instalação)
4. [Variáveis de Ambiente](#4-variáveis-de-ambiente)
5. [Deploy na Vercel](#5-deploy-na-vercel)
6. [Personalização de Cores e Nome](#6-personalização-de-cores-e-nome)
7. [Configurando Google OAuth](#7-configurando-google-oauth)
8. [Estrutura de Pastas](#8-estrutura-de-pastas)
9. [FAQ](#9-faq)

---

## 1. Visão Geral do Produto

O **DevBase** é um starter kit de produção para desenvolvedores brasileiros que precisam lançar um SaaS rapidamente. Ele resolve os problemas mais comuns na construção de produtos digitais no Brasil: integração de pagamentos nacionais (PIX e boleto via Pagar.me), autenticação completa, dashboard pronto e infraestrutura escalável — tudo documentado em português.

### O que está incluído

| Módulo | Descrição |
|--------|-----------|
| **Autenticação** | Login/cadastro por e-mail, Google OAuth, reset de senha, magic link |
| **Billing brasileiro** | Pagar.me com PIX, boleto e cartão de crédito. Webhook de pagamento pronto |
| **Dashboard** | Área logada com sidebar, header, página de planos, equipe e configurações |
| **Landing page** | Hero, features, pricing, stack e CTA — pronta para customizar |
| **Proteção de rotas** | Middleware Next.js que redireciona usuários não autenticados |
| **E-mail transacional** | Resend integrado com templates em PT-BR |
| **Banco de dados** | Schema Supabase com RLS, triggers e funções prontas |
| **TypeScript strict** | Código 100% tipado |
| **Deploy Vercel** | Configurado e otimizado para Next.js 14 App Router |

### Stack tecnológica

- **Framework:** Next.js 14 (App Router, Server Components, SSR)
- **Banco de dados & Auth:** Supabase (PostgreSQL + Auth)
- **Pagamentos:** Pagar.me (PIX, boleto, crédito)
- **E-mail:** Resend
- **Estilização:** Tailwind CSS + shadcn/ui + DM Sans
- **Linguagem:** TypeScript (strict mode)
- **Deploy:** Vercel

---

## 2. Pré-requisitos

Antes de instalar o DevBase, você precisará criar contas nos seguintes serviços:

### Contas necessárias

| Serviço | Para que serve | Link |
|---------|---------------|------|
| **Node.js 18+** | Ambiente de execução local | [nodejs.org](https://nodejs.org) |
| **Supabase** | Banco de dados e autenticação | [supabase.com](https://supabase.com) |
| **Vercel** | Hospedagem e deploy | [vercel.com](https://vercel.com) |
| **Pagar.me** | Processar pagamentos (PIX/boleto) | [pagar.me](https://pagar.me) |
| **Resend** | Envio de e-mails transacionais | [resend.com](https://resend.com) |

### Contas opcionais

| Serviço | Para que serve |
|---------|---------------|
| **Google Cloud** | Login com Google (OAuth) |

### Requisitos de sistema

- Node.js **18.x ou superior** (`node -v` para verificar)
- npm 9+ ou pnpm 8+
- Git instalado
- Editor de código (VS Code recomendado)

---

## 3. Guia de Instalação

Siga os passos abaixo em ordem. Tempo estimado: **30 a 60 minutos**.

### Passo 1 — Clonar o repositório

```bash
git clone https://github.com/seu-usuario/devbase
cd devbase
```

### Passo 2 — Instalar dependências

```bash
npm install
```

### Passo 3 — Configurar variáveis de ambiente

Copie o arquivo de exemplo e preencha com suas chaves:

```bash
cp .env.example .env.local
```

Abra o `.env.local` no seu editor e preencha cada variável (veja a seção [4. Variáveis de Ambiente](#4-variáveis-de-ambiente) para instruções detalhadas).

### Passo 4 — Criar o projeto no Supabase

1. Acesse [supabase.com](https://supabase.com) e crie uma conta
2. Clique em **New Project**
3. Escolha um nome, senha forte e a região `South America (São Paulo)`
4. Aguarde o projeto inicializar (cerca de 2 minutos)
5. Vá em **Project Settings → API**
6. Copie a **URL do projeto** e as chaves **anon/public** e **service_role**
7. Cole essas chaves no seu `.env.local`

### Passo 5 — Criar as tabelas no banco

1. No painel do Supabase, acesse **SQL Editor**
2. Clique em **New query**
3. Copie todo o conteúdo do arquivo `supabase/schema.sql` do DevBase
4. Cole no editor e clique em **Run**

Isso criará as tabelas `profiles` e `payments`, as políticas de RLS, os triggers e as funções necessárias.

### Passo 6 — Rodar localmente

```bash
npm run dev
```

Acesse [http://localhost:3000](http://localhost:3000). A landing page deve aparecer. Tente criar uma conta em `/auth/cadastro` para testar o fluxo completo.

### Passo 7 — Verificar o funcionamento

Checklist rápido:

- [ ] Landing page carregou em `http://localhost:3000`
- [ ] Cadastro funciona em `/auth/cadastro`
- [ ] Login funciona em `/auth/login`
- [ ] Após login, o dashboard aparece em `/dashboard`
- [ ] O perfil do usuário foi criado em **Supabase → Table Editor → profiles**

---

## 4. Variáveis de Ambiente

O arquivo `.env.local` contém todas as configurações sensíveis do DevBase. **Nunca commite esse arquivo no git** — ele já está listado no `.gitignore`.

### Supabase (obrigatório)

```env
NEXT_PUBLIC_SUPABASE_URL=https://SEU_PROJETO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5...
```

| Variável | Onde encontrar |
|----------|---------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API → Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Project Settings → API → anon/public |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Project Settings → API → service_role (nunca exponha no client) |

> As variáveis com prefixo `NEXT_PUBLIC_` ficam visíveis no browser. Nunca adicione esse prefixo à `SUPABASE_SERVICE_ROLE_KEY`.

### Configurações da aplicação (obrigatório)

```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME="DevBase"
```

| Variável | Descrição |
|----------|-----------|
| `NEXT_PUBLIC_APP_URL` | URL base da aplicação. Em produção: `https://seudominio.com.br` |
| `NEXT_PUBLIC_APP_NAME` | Nome do produto exibido na UI |

### Pagar.me (necessário para billing)

```env
PAGARME_API_KEY=ak_test_sua_chave_aqui
PAGARME_WEBHOOK_SECRET=seu_webhook_secret_aqui
```

| Variável | Onde encontrar |
|----------|---------------|
| `PAGARME_API_KEY` | Pagar.me → Minha Conta → Chaves de API |
| `PAGARME_WEBHOOK_SECRET` | Pagar.me → Configurações → Webhooks → Secret |

Use o prefixo `ak_test_` para ambiente de testes e `ak_live_` para produção.

**Como configurar o webhook no Pagar.me:**
1. Acesse **Configurações → Webhooks**
2. Clique em **Adicionar webhook**
3. URL: `https://seudominio.com.br/api/webhooks/pagarme`
4. Eventos: `order.paid`, `order.canceled`, `charge.refunded`
5. Copie o secret gerado para `PAGARME_WEBHOOK_SECRET`

### Resend (necessário para e-mails)

```env
RESEND_API_KEY=re_sua_chave_aqui
RESEND_FROM_EMAIL=noreply@seudominio.com.br
```

| Variável | Onde encontrar |
|----------|---------------|
| `RESEND_API_KEY` | Resend → API Keys → Create API Key |
| `RESEND_FROM_EMAIL` | O e-mail remetente. Precisa ser um domínio verificado no Resend |

> Para verificar seu domínio no Resend: **Resend → Domains → Add Domain** e siga as instruções de DNS.

### IDs de planos Pagar.me (necessário para billing)

```env
NEXT_PUBLIC_PLAN_BASIC_ID=plan_basico_id
NEXT_PUBLIC_PLAN_PRO_ID=plan_pro_id
NEXT_PUBLIC_PLAN_AGENCY_ID=plan_agencia_id
```

Esses IDs são os identificadores dos planos criados no painel do Pagar.me. Cada plano deve ser cadastrado lá com o preço e recorrência corretos antes de preencher essas variáveis.

---

## 5. Deploy na Vercel

### Opção A — Deploy via interface (recomendado)

1. Faça push do projeto para um repositório no GitHub
2. Acesse [vercel.com](https://vercel.com) e clique em **Add New → Project**
3. Conecte sua conta do GitHub e selecione o repositório
4. Na etapa de configuração, **não altere** as configurações de build (a Vercel detecta Next.js automaticamente)
5. Antes de fazer o deploy, clique em **Environment Variables** e adicione todas as variáveis do seu `.env.local`
6. Clique em **Deploy**

### Opção B — Deploy via CLI

```bash
# Instalar a CLI da Vercel
npm i -g vercel

# Fazer login
vercel login

# Deploy de preview
vercel

# Deploy para produção
vercel --prod
```

### Configurando as variáveis de ambiente na Vercel

No painel da Vercel, vá em **Project → Settings → Environment Variables** e adicione cada variável do `.env.local` nos environments **Production**, **Preview** e **Development**.

> Em produção, `NEXT_PUBLIC_APP_URL` deve ser a URL real do seu projeto (ex: `https://seuapp.vercel.app` ou seu domínio customizado).

### Configurando domínio customizado

1. Vercel → **Project → Settings → Domains**
2. Clique em **Add Domain** e insira seu domínio
3. Siga as instruções para configurar os registros DNS no seu provedor (Registro.br, Cloudflare, etc.)
4. Aguarde a propagação (pode levar até 24h)
5. Atualize `NEXT_PUBLIC_APP_URL` com o novo domínio

### Atualizando o URL de callback no Supabase

Após configurar o domínio, atualize o Supabase para aceitar redirecionamentos do novo URL:

1. Supabase → **Authentication → URL Configuration**
2. Em **Site URL**, coloque: `https://seudominio.com.br`
3. Em **Redirect URLs**, adicione: `https://seudominio.com.br/auth/callback`

---

## 6. Personalização de Cores e Nome

### Trocando o nome do produto

O DevBase usa o nome do produto em vários lugares. A forma mais fácil de trocar é fazer uma busca global:

**No VS Code:** `Ctrl+Shift+H` (Find and Replace in Files)
- Buscar: `DevBase`
- Substituir pelo nome do seu produto

Atualize também a variável de ambiente:

```env
NEXT_PUBLIC_APP_NAME="Seu Produto"
```

### Trocando as cores

As cores são definidas como variáveis CSS em `src/app/globals.css`. Edite os valores conforme a identidade visual da sua marca:

```css
:root {
  /* Fundos (escala de escuro) */
  --bg:   #0a0a0a;   /* fundo principal */
  --bg-2: #111111;   /* fundo secundário */
  --bg-3: #1a1a1a;   /* fundo terciário */
  --bg-4: #222222;   /* fundo quaternário */

  /* Textos */
  --text:   #ffffff;               /* texto principal */
  --text-2: rgba(255,255,255,0.6); /* texto secundário */
  --text-3: rgba(255,255,255,0.35);/* texto terciário */

  /* Accent (cor de destaque — troque para a cor da sua marca) */
  --accent:        #6366f1;               /* indigo padrão */
  --accent-2:      #818cf8;               /* indigo mais claro */
  --accent-bg:     rgba(99,102,241,0.12); /* fundo do accent */
  --accent-border: rgba(99,102,241,0.3);  /* borda do accent */

  /* Status */
  --green:    #22c55e;              /* sucesso / ativo */
  --green-bg: rgba(34,197,94,0.1);  /* fundo verde */
  --red:      #ef4444;              /* erro */

  /* Bordas arredondadas */
  --radius:    8px;
  --radius-lg: 12px;
}
```

**Exemplos de paletas alternativas:**

| Marca | `--accent` | `--accent-2` | `--accent-bg` |
|-------|-----------|-------------|--------------|
| Azul | `#3b82f6` | `#60a5fa` | `rgba(59,130,246,0.12)` |
| Roxo | `#8b5cf6` | `#a78bfa` | `rgba(139,92,246,0.12)` |
| Rosa | `#ec4899` | `#f472b6` | `rgba(236,72,153,0.12)` |
| Laranja | `#f97316` | `#fb923c` | `rgba(249,115,22,0.12)` |

### Trocando a fonte

A fonte padrão é **DM Sans**. Para trocar, edite `tailwind.config.ts` e substitua a importação em `src/app/layout.tsx`:

```typescript
// tailwind.config.ts
fontFamily: {
  sans: ["SuaFonte", ...defaultTheme.fontFamily.sans],
}
```

> Fontes disponíveis gratuitamente: [fonts.google.com](https://fonts.google.com)

---

## 7. Configurando Google OAuth

O login com Google no DevBase é gerenciado pelo Supabase Auth. Siga os passos abaixo:

### Passo 1 — Criar projeto no Google Cloud

1. Acesse [console.cloud.google.com](https://console.cloud.google.com)
2. Crie um novo projeto (ou selecione um existente)
3. No menu lateral, vá em **APIs e serviços → Credenciais**
4. Clique em **Criar credenciais → ID do cliente OAuth**
5. Em **Tipo de aplicativo**, selecione **Aplicativo da Web**
6. Dê um nome (ex: "DevBase OAuth")

### Passo 2 — Configurar URLs autorizadas

Na tela de criação do cliente OAuth, adicione:

**Origens JavaScript autorizadas:**
```
http://localhost:3000
https://seudominio.com.br
```

**URIs de redirecionamento autorizados:**
```
https://SEU_PROJETO.supabase.co/auth/v1/callback
```

> Substitua `SEU_PROJETO` pela referência do seu projeto no Supabase (visível na URL do painel).

Clique em **Criar** e anote o **Client ID** e o **Client Secret**.

### Passo 3 — Ativar o Google no Supabase

1. No Supabase, vá em **Authentication → Providers**
2. Encontre **Google** e clique para expandir
3. Ative o toggle **Enabled**
4. Cole o **Client ID** e o **Client Secret** obtidos no Google Cloud
5. Clique em **Save**

### Passo 4 — Verificar o callback no projeto

O arquivo `src/app/auth/callback/route.ts` já está configurado para lidar com o retorno do OAuth. Certifique-se de que `NEXT_PUBLIC_APP_URL` está correto no `.env.local` para que o redirecionamento funcione.

### Testando

1. Rode o projeto localmente (`npm run dev`)
2. Acesse `/auth/login`
3. Clique em **Entrar com Google**
4. Faça login com uma conta Google
5. Você deve ser redirecionado para `/dashboard`

---

## 8. Estrutura de Pastas

```
devbase/
├── src/
│   ├── app/                        # Next.js App Router (rotas e páginas)
│   │   ├── auth/                   # Rotas públicas de autenticação
│   │   │   ├── login/              # Página de login (e-mail + Google)
│   │   │   ├── cadastro/           # Página de cadastro
│   │   │   ├── reset-senha/        # Solicitação de reset de senha
│   │   │   ├── nova-senha/         # Definição da nova senha
│   │   │   └── callback/           # Handler do callback OAuth
│   │   ├── dashboard/              # Área protegida (requer login)
│   │   │   ├── page.tsx            # Home do dashboard (métricas, checklist)
│   │   │   ├── layout.tsx          # Layout com sidebar e header
│   │   │   ├── planos/             # Página de planos e upgrade
│   │   │   ├── equipe/             # Gerenciamento de time (plano Pro)
│   │   │   └── configuracoes/      # Configurações de perfil e integrações
│   │   ├── api/                    # API Routes (backend)
│   │   │   └── webhooks/
│   │   │       └── pagarme/        # Webhook do Pagar.me (pagamentos)
│   │   ├── layout.tsx              # Layout raiz (fontes, metadados)
│   │   ├── page.tsx                # Landing page pública
│   │   └── globals.css             # Estilos globais e variáveis CSS
│   │
│   ├── components/                 # Componentes React reutilizáveis
│   │   ├── auth/                   # Componentes de autenticação
│   │   ├── dashboard/
│   │   │   ├── Sidebar.tsx         # Sidebar de navegação do dashboard
│   │   │   └── Header.tsx          # Header fixo com título e avatar
│   │   ├── marketing/              # Componentes da landing page
│   │   └── ui/                     # Componentes genéricos (botões, inputs)
│   │
│   ├── lib/                        # Utilitários e configurações
│   │   ├── supabase/
│   │   │   ├── client.ts           # Supabase para uso no browser (Client Components)
│   │   │   └── server.ts           # Supabase para Server Components e Route Handlers
│   │   └── utils.ts                # Funções auxiliares (formatBRL, getInitials, cn...)
│   │
│   ├── middleware.ts               # Proteção de rotas (redireciona não autenticados)
│   │
│   └── types/
│       └── index.ts                # Tipos TypeScript centralizados (Profile, Plan...)
│
├── supabase/
│   └── schema.sql                  # Schema completo do banco (tabelas, RLS, triggers)
│
├── .env.example                    # Template de variáveis de ambiente
├── .env.local                      # Suas variáveis locais (não commitar)
├── next.config.js                  # Configurações do Next.js (domínios de imagem)
├── tailwind.config.ts              # Configuração do Tailwind (cores, fontes, animações)
├── tsconfig.json                   # Configuração do TypeScript
└── package.json                    # Dependências e scripts
```

### Arquivos mais importantes para customização

| Arquivo | O que você vai editar |
|---------|----------------------|
| `src/app/globals.css` | Cores, tipografia, variáveis CSS |
| `src/app/page.tsx` | Landing page completa |
| `tailwind.config.ts` | Paleta de cores e fontes do Tailwind |
| `src/components/dashboard/Sidebar.tsx` | Itens de navegação do dashboard |
| `src/types/index.ts` | Planos, preços e features |
| `supabase/schema.sql` | Estrutura do banco de dados |

### Fluxo de autenticação e dados

```
Requisição
    │
    ▼
middleware.ts ──── não autenticado ──→ /auth/login
    │
  autenticado
    │
    ▼
Server Component
    │
    ▼
lib/supabase/server.ts  (SSR seguro, nunca expõe service_role)
    │
    ▼
Supabase (PostgreSQL + RLS)
    │
    ▼
Renderiza página com dados
```

---

## 9. FAQ

### Instalação e Configuração

**P: Posso usar pnpm ou yarn em vez de npm?**

Sim. Todos os comandos do DevBase funcionam com `pnpm install`, `pnpm dev`, etc. O projeto não tem dependência de gerenciador de pacotes específico.

---

**P: O projeto funciona com Node.js 16?**

Não. O Next.js 14 requer Node.js 18 ou superior. Use `nvm` para gerenciar versões: `nvm use 18`.

---

**P: Preciso criar as tabelas do banco manualmente toda vez?**

Apenas na primeira vez. Depois de rodar o `supabase/schema.sql` uma vez, as tabelas ficam persistidas no seu projeto Supabase.

---

**P: Aparece erro de "Invalid API Key" no Supabase. O que fazer?**

Verifique se copiou as chaves corretas. A `SUPABASE_SERVICE_ROLE_KEY` é diferente da `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Ambas estão em **Supabase → Project Settings → API**. Após alterar o `.env.local`, reinicie o servidor de desenvolvimento.

---

**P: O Google OAuth não redireciona corretamente após o login.**

Certifique-se de que:
1. A URI de redirecionamento no Google Cloud inclui exatamente `https://SEU_PROJETO.supabase.co/auth/v1/callback`
2. O `NEXT_PUBLIC_APP_URL` no `.env.local` bate com a URL que você está acessando
3. No Supabase, **Authentication → URL Configuration → Redirect URLs** contém `http://localhost:3000/auth/callback`

---

### Pagamentos

**P: O webhook do Pagar.me não está sendo chamado localmente.**

Em desenvolvimento local, o Pagar.me não consegue alcançar `localhost`. Use o [ngrok](https://ngrok.com) para expor sua porta local:

```bash
ngrok http 3000
```

Use a URL gerada (ex: `https://abc123.ngrok.io/api/webhooks/pagarme`) no painel do Pagar.me.

---

**P: Posso usar Stripe em vez de Pagar.me?**

O DevBase foi construído para o mercado brasileiro com Pagar.me. Você pode substituir por Stripe, mas precisará reescrever `src/app/api/webhooks/pagarme/route.ts` e a lógica de billing no dashboard. O restante do projeto não depende do Pagar.me.

---

**P: Como diferencio ambiente de teste e produção no Pagar.me?**

As chaves de API começam com `ak_test_` em teste e `ak_live_` em produção. Use chaves de teste durante o desenvolvimento — os pagamentos não são reais. Troque para `ak_live_` apenas no ambiente de produção.

---

**P: O plano do usuário não atualiza após o pagamento.**

Verifique se:
1. O webhook está configurado corretamente no Pagar.me
2. A `SUPABASE_SERVICE_ROLE_KEY` está correta (o webhook precisa burlar o RLS para atualizar o perfil)
3. O evento `order.paid` está selecionado nas configurações do webhook

---

### Dashboard e Rotas

**P: Como adicionar uma nova página no dashboard?**

1. Crie a pasta e o arquivo: `src/app/dashboard/minha-pagina/page.tsx`
2. Implemente o componente (pode copiar a estrutura de outra página como modelo)
3. Adicione o link na sidebar em `src/components/dashboard/Sidebar.tsx`

---

**P: Como restringir uma página do dashboard para planos específicos?**

No Server Component da página, busque o perfil do usuário e verifique o plano:

```typescript
// src/app/dashboard/minha-pagina/page.tsx
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function MinhaPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase
    .from("profiles")
    .select("plan")
    .eq("id", user!.id)
    .single();

  if (profile?.plan === "free") {
    redirect("/dashboard/planos");
  }

  return <div>Conteúdo exclusivo</div>;
}
```

---

**P: O middleware está bloqueando rotas que deveriam ser públicas.**

Edite `src/middleware.ts` e ajuste as condições. Por padrão, apenas rotas sob `/dashboard` são protegidas. Adicione exceções conforme necessário.

---

### Deploy e Produção

**P: O deploy na Vercel falha com erro de variável de ambiente.**

Verifique se todas as variáveis do `.env.local` foram adicionadas em **Vercel → Project → Settings → Environment Variables**. Variáveis com `NEXT_PUBLIC_` precisam estar marcadas como "Plain text" (não secret).

---

**P: As imagens do Supabase não carregam em produção.**

O `next.config.js` já inclui o domínio `*.supabase.co` na whitelist de imagens. Se estiver usando storage do Supabase com domínio customizado, adicione-o ao array `remotePatterns` em `next.config.js`.

---

**P: Como configurar um domínio customizado `.com.br`?**

1. Registre o domínio no [Registro.br](https://registro.br)
2. Na Vercel, vá em **Project → Settings → Domains** e adicione o domínio
3. Configure os registros DNS conforme indicado pela Vercel:
   - Para domínio raiz: registro `A` apontando para o IP da Vercel
   - Para subdomínio (`www`): registro `CNAME` para `cname.vercel-dns.com`
4. Atualize `NEXT_PUBLIC_APP_URL` e os URLs de callback no Supabase

---

**P: Como atualizar o projeto após fazer alterações?**

Se o repositório está conectado à Vercel via GitHub, qualquer push para a branch `main` dispara um novo deploy automaticamente. Para deploy manual, use `vercel --prod`.

---

**P: Preciso de suporte ou encontrei um bug. O que faço?**

Abra um issue no GitHub com logs e passos para reproduzir.
