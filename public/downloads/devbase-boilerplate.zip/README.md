# devbase

Boilerplate Next.js pra devs brasileiros lançarem SaaS em dias, não meses.

## O que está incluso
- Autenticação completa (email + Google OAuth)
- Billing com Pagar.me (PIX, boleto, cartão)
- Dashboard com sidebar, métricas e admin panel
- Email transacional com Resend
- Documentação 100% em PT-BR
- Deploy na Vercel em 1 clique

## Stack
Next.js 14 · TypeScript · Supabase · Tailwind · shadcn/ui · Pagar.me · Resend · Vercel

## Como começar
1. Clone o repositório
2. Copie `.env.exemplo` para `.env.local` e preencha as chaves
3. `npm install && npm run dev`

## Documentação
Ver [DOCUMENTATION.md](./DOCUMENTATION.md)

## Licença
Uso pessoal e comercial liberado para compradores.
